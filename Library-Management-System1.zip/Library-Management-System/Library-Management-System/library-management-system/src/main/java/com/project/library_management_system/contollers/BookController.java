package com.project.library_management_system.contollers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import com.project.library_management_system.model.Book;
import com.project.library_management_system.services.BookService;


@CrossOrigin("http://localhost:3000/")


@RestController
@RequestMapping("/api/books")
public class BookController {
    
    @Autowired
    BookService bookService;

    @PostMapping
    public Book createBook(@RequestBody Book book) {
    
        return bookService.saveBook(book);
    }

    @GetMapping
    public Page<Book> getAllBooks(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size ) {
        return bookService.getAllBooks(page, size);
    }
    
    @GetMapping("/{id}")
    public Optional<Book> getBookById(@PathVariable Long id) {
        return bookService.getBookById(id);
    }
    
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book book) {
        //TODO: process PUT request
        return bookService.updateBook(id, book);
    }
    
    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id){
        bookService.deleteBook(id);
    }

    @GetMapping("/search")
    public Page<Book> searchBooks(@RequestParam String query, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) {
        return bookService.searchBook(query, page, size);
    }
    
}
