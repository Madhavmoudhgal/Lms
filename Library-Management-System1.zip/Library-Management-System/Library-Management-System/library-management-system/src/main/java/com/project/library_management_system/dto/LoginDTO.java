package com.project.library_management_system.dto;

import lombok.Data;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin("http://localhost:3000/")

@Data
public class LoginDTO {
    private String username;
    private String password;
}
