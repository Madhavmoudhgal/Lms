import React, { useState, useEffect } from 'react';
import { Container, Card, Row, Col, Badge, Spinner, Table, Form, Button, InputGroup } from 'react-bootstrap';
import { FaBook, FaUser, FaExclamationTriangle, FaClock, FaSearch, FaArrowLeft, FaCheckCircle, FaMoneyBillWave, FaChartBar, FaHandPaper, FaUndo, FaSignOutAlt, FaEnvelope } from 'react-icons/fa';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const AdminReports = () => {
    const [users, setUsers] = useState([]);
    const [selectedUser, setSelectedUser] = useState(null);
    const [lendings, setLendings] = useState([]);
    const [filteredLendings, setFilteredLendings] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [stats, setStats] = useState({
        totalBorrowed: 0,
        totalOverdue: 0,
        totalFine: 0
    });
    const [collectingLendings, setCollectingLendings] = useState({});
    const [returningLendings, setReturningLendings] = useState({});
    const navigate = useNavigate();

    const fetchUsers = async () => {
        try {
            const token = localStorage.getItem('token');
            const role = localStorage.getItem('role')?.toUpperCase();
            
            if (!token || role !== 'ADMIN') {
                toast.error('Unauthorized access');
                navigate('/login');
                return;
            }

            const response = await axios.get('http://localhost:8080/api/users', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.data) {
                throw new Error('Failed to fetch users');
            }

            setUsers(response.data);
            setError(null);
        } catch (error) {
            console.error('Error fetching users:', error);
            if (error.response?.status === 403) {
                toast.error('Access denied. Please login as admin.');
                localStorage.clear();
                navigate('/login');
                return;
            }
            toast.error('Failed to fetch users data');
            setError(error.message);
        } finally {
            setLoading(false);
        }
    };

    const fetchAllLendings = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:8080/api/lending/getAllLendings', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.data) {
                throw new Error('Failed to fetch lendings');
            }

            setLendings(response.data);
            setFilteredLendings(response.data);
            setError(null);
        } catch (error) {
            console.error('Error fetching lendings:', error);
            if (error.response?.status === 403) {
                toast.error('Access denied. Please login as admin.');
                localStorage.clear();
                navigate('/login');
                return;
            }
            toast.error('Failed to fetch lending data');
            setError(error.message);
        }
    };

    const fetchUserLendings = async (userId) => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:8080/api/lending/getAllLendings', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.data) {
                throw new Error('Failed to fetch lendings');
            }

            // Find the username for the selected user
            const selectedUser = users.find(u => u.id === userId);
            if (!selectedUser) {
                throw new Error('User not found');
            }

            // Filter lendings for the selected user by username
            const userLendings = response.data.filter(lending => lending.username === selectedUser.username);
            
            // Map the lendings to ensure we have the correct ID property
            const mappedLendings = userLendings.map(lending => ({
                ...lending,
                id: lending.lendingId // Ensure we're using lendingId as our id
            }));
            
            setLendings(mappedLendings);
            setFilteredLendings(mappedLendings);
            setSelectedUser(userId);
            setError(null);
        } catch (error) {
            console.error('Error fetching lendings:', error);
            if (error.response?.status === 403) {
                toast.error('Access denied. Please login as admin.');
                localStorage.clear();
                navigate('/login');
                return;
            }
            toast.error('Failed to fetch lending data');
            setError(error.message);
        }
    };

    const fetchStats = async () => {
        try {
            const token = localStorage.getItem('token');
            const [borrowedResponse, overdueResponse, fineResponse] = await Promise.all([
                axios.get('http://localhost:8080/api/lending/borrowedBooks/count/total', {
                    headers: { 
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                }),
                axios.get('http://localhost:8080/api/lending/overdue/count/total', {
                    headers: { 
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                }),
                axios.get('http://localhost:8080/api/fines/totalfine', {
                    headers: { 
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                })
            ]);

            setStats({
                totalBorrowed: borrowedResponse.data,
                totalOverdue: overdueResponse.data,
                totalFine: fineResponse.data.totalFine || 0
            });
        } catch (error) {
            console.error('Error fetching stats:', error);
            if (error.response?.status === 403) {
                toast.error('Access denied. Please login as admin.');
                localStorage.clear();
                navigate('/login');
                return;
            }
            toast.error('Failed to fetch statistics');
        }
    };

    const handleCollect = async (lendingId) => {
        try {
            if (!lendingId) {
                toast.error('Invalid lending ID');
                return;
            }

            setCollectingLendings(prev => ({ ...prev, [lendingId]: true }));
            const token = localStorage.getItem('token');
            
            if (!token) {
                toast.error('Please login to continue');
                navigate('/login');
                return;
            }

            const response = await axios.post(
                `http://localhost:8080/api/lending/collect/${lendingId}`,
                {},
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            if (response.data) {
                toast.success('Book collected successfully');
                // Update the local state immediately
                setLendings(prevLendings => 
                    prevLendings.map(lending => 
                        lending.lendingId === lendingId 
                            ? { ...lending, status: 'COLLECTED', collected: true }
                            : lending
                    )
                );
                setFilteredLendings(prevFiltered =>
                    prevFiltered.map(lending =>
                        lending.lendingId === lendingId
                            ? { ...lending, status: 'COLLECTED', collected: true }
                            : lending
                    )
                );
                fetchStats();
            }
        } catch (error) {
            console.error('Error collecting book:', error);
            if (error.response?.status === 403) {
                toast.error('Access denied. Please login as admin.');
                localStorage.clear();
                navigate('/login');
            } else {
                toast.error(error.response?.data?.message || 'Failed to collect book');
            }
        } finally {
            setCollectingLendings(prev => ({ ...prev, [lendingId]: false }));
        }
    };

    const handleReturn = async (lendingId) => {
        try {
            setReturningLendings(prev => ({ ...prev, [lendingId]: true }));
            const token = localStorage.getItem('token');
            
            if (!token) {
                toast.error('Please login to continue');
                navigate('/login');
                return;
            }

            const response = await axios.post(
                `http://localhost:8080/api/lending/return/${lendingId}`,
                {},
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            if (response.data) {
                toast.success('Book returned successfully');
                // Update the local state immediately
                setLendings(prevLendings => 
                    prevLendings.map(lending => 
                        lending.lendingId === lendingId 
                            ? { ...lending, status: 'RETURNED' }
                            : lending
                    )
                );
                setFilteredLendings(prevFiltered =>
                    prevFiltered.map(lending =>
                        lending.lendingId === lendingId
                            ? { ...lending, status: 'RETURNED' }
                            : lending
                    )
                );
                fetchStats();
            }
        } catch (error) {
            console.error('Error returning book:', error);
            if (error.response?.status === 403) {
                toast.error('Access denied. Please login as admin.');
                localStorage.clear();
                navigate('/login');
            } else {
                toast.error(error.response?.data?.message || 'Failed to return book');
            }
        } finally {
            setReturningLendings(prev => ({ ...prev, [lendingId]: false }));
        }
    };

    useEffect(() => {
        fetchUsers();
        fetchStats();
    }, []);

    useEffect(() => {
        let filtered = [...lendings];

        if (searchTerm) {
            filtered = filtered.filter(lending => 
                lending.bookName.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        if (statusFilter !== 'all') {
            filtered = filtered.filter(lending => lending.status === statusFilter);
        }

        setFilteredLendings(filtered);
    }, [searchTerm, statusFilter, lendings]);

    const handleLogout = () => {
        localStorage.clear();
        navigate('/login');
    };

    if (loading) {
        return (
            <div className="d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
                <div className="text-center">
                    <Spinner animation="border" role="status" className="mb-3" style={{ width: '3rem', height: '3rem' }}>
                        <span className="visually-hidden">Loading...</span>
                    </Spinner>
                    <h5 className="text-muted">Loading Reports...</h5>
                </div>
            </div>
        );
    }

    return (
        <div className="container-fluid py-4">
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h4 className="mb-0 fw-bold">
                    <FaChartBar className="text-primary me-2" />
                    Admin Reports
                </h4>
                <div className="d-flex gap-2">
                    <Button variant="outline-primary" onClick={() => navigate('/admin')} className="px-4 py-2">
                        <FaArrowLeft className="me-2" />
                        Back to Dashboard
                    </Button>
                    <Button variant="outline-danger" onClick={handleLogout} className="px-4 py-2">
                        <FaSignOutAlt className="me-2" />
                        Logout
                    </Button>
                </div>
            </div>

            <Row className="mb-4 g-4">
                <Col md={4}>
                    <Card className="border-0 shadow-sm h-100 hover-shadow" style={{ transition: 'transform 0.2s' }}>
                        <Card.Body className="p-4">
                            <div className="d-flex align-items-center">
                                <div className="bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                                    <FaBook className="text-primary" size={24} />
                                </div>
                                <div>
                                    <h6 className="text-muted mb-1">Total Borrowed</h6>
                                    <h3 className="mb-0 fw-bold">{stats.totalBorrowed}</h3>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card className="border-0 shadow-sm h-100 hover-shadow" style={{ transition: 'transform 0.2s' }}>
                        <Card.Body className="p-4">
                            <div className="d-flex align-items-center">
                                <div className="bg-danger bg-opacity-10 p-3 rounded-circle me-3">
                                    <FaExclamationTriangle className="text-danger" size={24} />
                                </div>
                                <div>
                                    <h6 className="text-muted mb-1">Overdue Books</h6>
                                    <h3 className="mb-0 fw-bold">{stats.totalOverdue}</h3>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card className="border-0 shadow-sm h-100 hover-shadow" style={{ transition: 'transform 0.2s' }}>
                        <Card.Body className="p-4">
                            <div className="d-flex align-items-center">
                                <div className="bg-warning bg-opacity-10 p-3 rounded-circle me-3">
                                    <FaMoneyBillWave className="text-warning" size={24} />
                                </div>
                                <div>
                                    <h6 className="text-muted mb-1">Total Fine</h6>
                                    <h3 className="mb-0 fw-bold">₹{stats.totalFine.toFixed(2)}</h3>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {!selectedUser ? (
                <Card className="border-0 shadow-sm">
                    <Card.Header className="bg-white border-0 py-4">
                        <div className="d-flex justify-content-between align-items-center">
                            <h5 className="mb-0 d-flex align-items-center fw-bold">
                                <FaUser className="me-2 text-primary" />
                                Users List
                            </h5>
                            <div className="d-flex align-items-center gap-2">
                                <span className="text-muted">Total Users:</span>
                                <span className="badge bg-primary px-3 py-2">{users.length}</span>
                            </div>
                        </div>
                    </Card.Header>
                    <Card.Body>
                        <div className="mb-4">
                            <InputGroup className="shadow-sm rounded-pill">
                                <InputGroup.Text className="bg-white border-end-0 rounded-start-pill">
                                    <FaSearch className="text-muted" />
                                </InputGroup.Text>
                                <Form.Control
                                    type="text"
                                    placeholder="Search users..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="border-start-0 rounded-end-pill"
                                />
                            </InputGroup>
                        </div>
                        <Row className="g-4">
                            {users
                                .filter(user => 
                                    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                    user.email.toLowerCase().includes(searchTerm.toLowerCase())
                                )
                                .map((user) => (
                                    <Col key={user.id} md={6} lg={4}>
                                        <Card 
                                            className="h-100 border-0 shadow-sm" 
                                            style={{ 
                                                transition: 'all 0.3s ease',
                                                cursor: 'pointer',
                                                background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                                                borderRadius: '20px',
                                                overflow: 'hidden'
                                            }}
                                            onMouseEnter={(e) => {
                                                e.currentTarget.style.transform = 'translateY(-8px)';
                                                e.currentTarget.style.boxShadow = '0 20px 40px rgba(0,0,0,0.1)';
                                            }}
                                            onMouseLeave={(e) => {
                                                e.currentTarget.style.transform = 'translateY(0)';
                                                e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.05)';
                                            }}
                                            onClick={() => fetchUserLendings(user.id)}
                                        >
                                            <Card.Body className="p-4">
                                                <div className="d-flex align-items-center mb-4">
                                                    <div 
                                                        style={{
                                                            width: '64px',
                                                            height: '64px',
                                                            background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                                                            borderRadius: '16px',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            marginRight: '20px',
                                                            boxShadow: '0 4px 12px rgba(79,70,229,0.2)'
                                                        }}
                                                    >
                                                        <FaUser size={32} className="text-white" />
                                                    </div>
                                                    <div>
                                                        <h5 className="mb-1 fw-bold">{user.username}</h5>
                                                        <p className="text-muted mb-0">{user.email}</p>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between align-items-center">
                                                    <div className="d-flex align-items-center gap-2">
                                                        <span className="text-muted">Role:</span>
                                                        <Badge 
                                                            bg={user.role === 'ADMIN' ? 'primary' : 'success'}
                                                            className="px-3 py-2"
                                                            style={{
                                                                borderRadius: '8px',
                                                                fontSize: '0.85rem',
                                                                fontWeight: '500'
                                                            }}
                                                        >
                                                            {user.role}
                                                        </Badge>
                                                    </div>
                                                    <Button
                                                        variant="primary"
                                                        size="sm"
                                                        className="d-flex align-items-center gap-2"
                                                        style={{
                                                            background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                                                            border: 'none',
                                                            borderRadius: '12px',
                                                            padding: '8px 20px',
                                                            fontSize: '0.9rem',
                                                            fontWeight: '500',
                                                            boxShadow: '0 4px 12px rgba(79,70,229,0.2)',
                                                            transition: 'all 0.3s ease'
                                                        }}
                                                        onMouseEnter={(e) => {
                                                            e.currentTarget.style.transform = 'translateY(-2px)';
                                                            e.currentTarget.style.boxShadow = '0 6px 16px rgba(79,70,229,0.3)';
                                                        }}
                                                        onMouseLeave={(e) => {
                                                            e.currentTarget.style.transform = 'translateY(0)';
                                                            e.currentTarget.style.boxShadow = '0 4px 12px rgba(79,70,229,0.2)';
                                                        }}
                                                    >
                                                        <FaChartBar />
                                                        View History
                                                    </Button>
                                                </div>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                ))}
                        </Row>
                    </Card.Body>
                </Card>
            ) : (
                <Card className="border-0 shadow-sm">
                    <Card.Header className="bg-white border-0 py-4">
                        <div className="d-flex justify-content-between align-items-center">
                            <div className="d-flex align-items-center">
                                <Button
                                    variant="link"
                                    className="p-0 me-3"
                                    onClick={() => {
                                        setSelectedUser(null);
                                        fetchAllLendings();
                                    }}
                                >
                                    <FaArrowLeft className="text-primary" size={20} />
                                </Button>
                                <h5 className="mb-0 d-flex align-items-center fw-bold">
                                    <FaBook className="me-2 text-primary" />
                                    Lending History
                                </h5>
                            </div>
                            <div className="d-flex align-items-center gap-2">
                                <span className="text-muted">Total Records:</span>
                                <span className="badge bg-primary px-3 py-2">{filteredLendings.length}</span>
                            </div>
                        </div>
                    </Card.Header>
                    <Card.Body>
                        <div className="mb-4">
                            <Row className="g-3">
                                <Col md={6}>
                                    <InputGroup className="shadow-sm rounded-pill">
                                        <InputGroup.Text className="bg-white border-end-0 rounded-start-pill">
                                            <FaSearch className="text-muted" />
                                        </InputGroup.Text>
                                        <Form.Control
                                            type="text"
                                            placeholder="Search by book name..."
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                            className="border-start-0 rounded-end-pill"
                                        />
                                    </InputGroup>
                                </Col>
                                <Col md={6}>
                                    <Form.Select
                                        value={statusFilter}
                                        onChange={(e) => setStatusFilter(e.target.value)}
                                        className="form-select shadow-sm rounded-pill"
                                    >
                                        <option value="all">All Status</option>
                                        <option value="ACTIVE">Active</option>
                                        <option value="OVERDUE">Overdue</option>
                                        <option value="RETURNED">Returned</option>
                                    </Form.Select>
                                </Col>
                            </Row>
                        </div>
                        <div className="table-responsive">
                            <Table hover className="align-middle">
                                <thead className="bg-light">
                                    <tr>
                                        <th className="border-0">Book</th>
                                        <th className="border-0">Borrow Date</th>
                                        <th className="border-0">Due Date</th>
                                        <th className="border-0">Status</th>
                                        <th className="border-0">Fine</th>
                                        <th className="border-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredLendings.map((lending) => (
                                        <tr key={lending.lendingId}>
                                            <td>
                                                <div className="d-flex align-items-center">
                                                    <img 
                                                        src={lending.imageUrl} 
                                                        alt={lending.bookName}
                                                        className="me-3 rounded"
                                                        style={{ width: '50px', height: '50px', objectFit: 'cover' }}
                                                    />
                                                    <div>
                                                        <div className="fw-medium">{lending.bookName}</div>
                                                        <small className="text-muted">ID: {lending.lendingId}</small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div className="d-flex align-items-center">
                                                    <FaClock className="me-2 text-muted" />
                                                    {new Date(lending.borrowDate).toLocaleDateString()}
                                                </div>
                                            </td>
                                            <td>
                                                <div className="d-flex align-items-center">
                                                    <FaCheckCircle className="me-2 text-muted" />
                                                    {new Date(lending.dueDate).toLocaleDateString()}
                                                </div>
                                            </td>
                                            <td>
                                                <span className={`badge px-3 py-2 ${
                                                    lending.status === 'RETURNED' ? 'bg-success' :
                                                    lending.status === 'OVERDUE' ? 'bg-danger' :
                                                    lending.status === 'COLLECTED' ? 'bg-info' :
                                                    'bg-primary'
                                                }`}>
                                                    {lending.status}
                                                </span>
                                            </td>
                                            <td>
                                                {lending.fineAmount > 0 && (
                                                    <span className="text-danger fw-medium">
                                                        ₹{lending.fineAmount.toFixed(2)}
                                                    </span>
                                                )}
                                            </td>
                                            <td>
                                                <div className="d-flex gap-2">
                                                    {lending.status === 'ACTIVE' && (
                                                        <Button
                                                            variant="success"
                                                            size="sm"
                                                            onClick={() => handleCollect(lending.lendingId)}
                                                            disabled={collectingLendings[lending.lendingId]}
                                                            style={{
                                                                background: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
                                                                border: 'none',
                                                                borderRadius: '12px',
                                                                padding: '8px 20px',
                                                                fontSize: '0.9rem',
                                                                fontWeight: '500',
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                gap: '8px'
                                                            }}
                                                        >
                                                            {collectingLendings[lending.lendingId] ? (
                                                                <>
                                                                    <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                                                    Collecting...
                                                                </>
                                                            ) : (
                                                                <>
                                                                    <FaHandPaper />
                                                                    Collect
                                                                </>
                                                            )}
                                                        </Button>
                                                    )}
                                                    {lending.status === 'COLLECTED' && (
                                                        <Button
                                                            variant="primary"
                                                            size="sm"
                                                            onClick={() => handleReturn(lending.lendingId)}
                                                            disabled={returningLendings[lending.lendingId]}
                                                            style={{
                                                                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                                                                border: 'none',
                                                                borderRadius: '12px',
                                                                padding: '8px 20px',
                                                                fontSize: '0.9rem',
                                                                fontWeight: '500',
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                gap: '8px'
                                                            }}
                                                        >
                                                            {returningLendings[lending.lendingId] ? (
                                                                <>
                                                                    <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                                                    Returning...
                                                                </>
                                                            ) : (
                                                                <>
                                                                    <FaUndo />
                                                                    Return
                                                                </>
                                                            )}
                                                        </Button>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                        </div>
                    </Card.Body>
                </Card>
            )}
        </div>
    );
};

export default AdminReports; 