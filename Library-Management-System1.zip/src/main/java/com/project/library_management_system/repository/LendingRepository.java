package com.project.library_management_system.repository;

import com.project.library_management_system.dto.LendingDto;
import com.project.library_management_system.entity.LendingEntity;
import com.project.library_management_system.entity.userEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface LendingRepository extends JpaRepository<LendingEntity, Long> {
    Integer countByReturnDateIsNull();
    Long countByDueDateBeforeAndReturnDateIsNull(LocalDate date);

    @Query("SELECT new com.project.library_management_system.dto.LendingDto(l.id, u.username, b.title, b.imageUrl, l.borrowDate, l.dueDate, CASE WHEN l.returnDate IS NOT NULL THEN 'Returned' WHEN l.dueDate < CURRENT_DATE THEN 'Overdue' ELSE 'Active' END, COALESCE(f.fineAmount, 0)) " +
           "FROM LendingEntity l " +
           "JOIN l.user u " +
           "JOIN l.book b " +
           "LEFT JOIN FineEntity f ON l.id = f.lending.id")
    List<LendingDto> getAllLendings();
} 