package com.project.library_management_system.controllers;

import com.project.library_management_system.dto.LendingDto;
import com.project.library_management_system.entity.LendingEntity;
import com.project.library_management_system.services.LendingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/lending")
@CrossOrigin(origins = "http://localhost:3000")
public class LendingController {

    @Autowired
    private LendingService lendingService;

    @GetMapping("/getAllLendings")
    public ResponseEntity<List<LendingDto>> displayLendingsDetails() {
        try {
            List<LendingDto> lendings = lendingService.displayLendingsDetails();
            return ResponseEntity.ok(lendings);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/collect/{id}")
    public ResponseEntity<Map<String, Object>> collectBook(@PathVariable Long id) {
        return lendingService.markAsCollected(id);
    }

    @PostMapping("/return/{id}")
    public ResponseEntity<Map<String, Object>> returnBook(@PathVariable Long id) {
        return lendingService.markAsReturned(id);
    }

    @GetMapping("/borrowedBooks/count/total")
    public ResponseEntity<Integer> getBorrowedBooksTotal() {
        try {
            return ResponseEntity.ok(lendingService.getBorrowedBooks());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/overdue/count/total")
    public ResponseEntity<Long> getOverDueBooksTotal() {
        try {
            return ResponseEntity.ok(lendingService.getTotalOverdueBooks());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/history")
    public ResponseEntity<List<LendingDto>> getHistory() {
        return lendingService.getHistory();
    }
} 