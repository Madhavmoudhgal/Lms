package com.project.library_management_system.serviceImplementation;

import com.project.library_management_system.dto.LendingDto;
import com.project.library_management_system.entity.FineEntity;
import com.project.library_management_system.entity.LendingEntity;
import com.project.library_management_system.entity.userEntity;
import com.project.library_management_system.repository.FineRepository;
import com.project.library_management_system.repository.LendingRepository;
import com.project.library_management_system.repository.userRepository;
import com.project.library_management_system.services.LendingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@CrossOrigin("http://localhost:3000/")
@Service
public class LendingServiceImplementation implements LendingService {
    @Autowired
    private LendingRepository lendingRepository;
    @Autowired
    private userRepository userRepository;
    @Autowired
    private FineRepository fineRepository;

    @Override
    public List<LendingEntity> getAllLendings() {
        return lendingRepository.findAll();
    }

    @Override
    public ResponseEntity<Map<String, Object>> markAsCollected(Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<LendingEntity> lendingOpt = lendingRepository.findById(id);
            if (lendingOpt.isEmpty()) {
                response.put("status", "error");
                response.put("message", "Lending not found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            LendingEntity lending = lendingOpt.get();
            lending.setReturnDate(LocalDate.now());
            lendingRepository.save(lending);

            response.put("status", "success");
            response.put("message", "Book marked as collected");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @Override
    public ResponseEntity<Map<String, Object>> markAsReturned(Long id) {
        return markAsCollected(id);
    }

    @Override
    public List<LendingDto> displayLendingsDetails() {
        return lendingRepository.getAllLendings();
    }

    @Override
    public Integer getBorrowedBooks() {
        return lendingRepository.countByReturnDateIsNull();
    }

    @Override
    public Long getTotalOverdueBooks() {
        return lendingRepository.countByDueDateBeforeAndReturnDateIsNull(LocalDate.now());
    }

    @Override
    public ResponseEntity<List<LendingDto>> getHistory() {
        String username = getLoggedInUsername();
        Optional<userEntity> userOpt = userRepository.findByUsername(username);
        
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.emptyList());
        }

        userEntity user = userOpt.get();
        List<LendingEntity> userLendings = lendingRepository.findByUser(user);
        
        List<LendingDto> lendingDtos = userLendings.stream()
            .map(lending -> {
                LendingDto dto = new LendingDto();
                dto.setLendingId(lending.getId());
                dto.setUsername(lending.getUser().getUsername());
                dto.setBookName(lending.getBook().getTitle());
                dto.setImageUrl(lending.getBook().getImageUrl());
                dto.setBorrowDate(lending.getBorrowDate());
                dto.setDueDate(lending.getDueDate());
                dto.setStatus(lending.getReturnDate() != null ? "Returned" : 
                         LocalDate.now().isAfter(lending.getDueDate()) ? "Overdue" : "Active");
                return dto;
            })
            .collect(Collectors.toList());

        return ResponseEntity.ok(lendingDtos);
    }

    private String getLoggedInUsername() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            return ((UserDetails) principal).getUsername();
        }
        return principal.toString();
    }
} 