import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button, Container, Table, Form, Row, Col, Badge, Spinner } from 'react-bootstrap';
import axiosInstance from '../axiosInstance';
import { FaSearch, FaTimes, FaPlus, FaEdit, FaTrash, FaBook, FaUserCog, FaFilter, FaSort, FaChartBar, FaSignOutAlt } from 'react-icons/fa';
import { toast } from 'react-toastify';
import SearchInput from './SearchInput';

const AdminDashboard = () => {
    const navigate = useNavigate();
    const [books, setBooks] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredBooks, setFilteredBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [deletingBooks, setDeletingBooks] = useState({});
    const [filterType, setFilterType] = useState('all');
    const [sortBy, setSortBy] = useState('recent');

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        try {
            const response = await axiosInstance.get('/api/books');
            const bookData = response.data.content;
            setBooks(bookData);
            setFilteredBooks(bookData);
        } catch (error) {
            console.error('Error fetching books:', error);
            toast.error('Failed to load books. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        let results = [...books];

        // Apply search filter
        if (searchTerm) {
            results = results.filter(book =>
                book.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                book.author?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                book.isbn?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                book.copies_available?.toString().toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        // Apply availability filter
        if (filterType === 'available') {
            results = results.filter(book => book.copies_available > 0);
        } else if (filterType === 'out-of-stock') {
            results = results.filter(book => book.copies_available === 0);
        }

        // Apply sorting
        switch (sortBy) {
            case 'title':
                results.sort((a, b) => a.title.localeCompare(b.title));
                break;
            case 'author':
                results.sort((a, b) => a.author.localeCompare(b.author));
                break;
            case 'availability':
                results.sort((a, b) => b.copies_available - a.copies_available);
                break;
            default: // 'recent'
                break;
        }

        setFilteredBooks(results);
    }, [searchTerm, books, filterType, sortBy]);

    const deleteBook = async (id) => {
        setDeletingBooks(prev => ({ ...prev, [id]: true }));
        try {
            await axiosInstance.delete(`/api/books/${id}`);
            setBooks(books.filter(book => book.id !== id));
            toast.success('Book deleted successfully');
        } catch (error) {
            console.error('Error deleting book:', error);
            toast.error('Failed to delete book. Please try again.');
        } finally {
            setDeletingBooks(prev => ({ ...prev, [id]: false }));
        }
    };

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleLogout = () => {
        localStorage.clear();
        navigate('/login');
    };

    return (
        <div className="min-vh-100" style={{ background: '#f8f9fa' }}>
            {/* Header Section */}
            <div style={{ 
                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                padding: '24px 0',
                marginBottom: '40px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
            }}>
                <Container fluid style={{ maxWidth: '1400px' }}>
                    <div className="d-flex justify-content-between align-items-center gap-4">
                        {/* Left side empty div for spacing */}
                        <div style={{ width: '200px' }}></div>

                        {/* Centered search bar */}
                        <div className="position-relative" style={{ flex: 1, maxWidth: '500px', margin: '0 auto' }}>
                            <SearchInput value={searchTerm} onChange={handleSearch} />
                        </div>

                        {/* Right side buttons */}
                        <div className="d-flex align-items-center gap-3" style={{ width: '200px', justifyContent: 'flex-end' }}>
                            <Link to="/admin-reports">
                                <Button
                                    variant="transparent"
                                    style={{
                                        background: 'rgba(255,255,255,0.1)',
                                        backdropFilter: 'blur(10px)',
                                        border: 'none',
                                        borderRadius: '12px',
                                        padding: '12px 24px',
                                        color: 'white',
                                        height: '48px',
                                        transition: 'all 0.3s ease',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center'
                                    }}
                                >
                                    <FaChartBar size={18} className="me-2" />
                                    Reports
                                </Button>
                            </Link>
                            <Link to="/member-management">
                                <Button
                                    variant="transparent"
                                    style={{
                                        background: 'rgba(255,255,255,0.1)',
                                        backdropFilter: 'blur(10px)',
                                        border: 'none',
                                        borderRadius: '12px',
                                        padding: '12px 24px',
                                        color: 'white',
                                        height: '48px',
                                        transition: 'all 0.3s ease',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center'
                                    }}
                                >
                                    <FaUserCog size={18} className="me-2" />
                                    Members
                                </Button>
                            </Link>
                            <Button
                                variant="transparent"
                                onClick={handleLogout}
                                style={{
                                    background: 'rgba(255,255,255,0.1)',
                                    backdropFilter: 'blur(10px)',
                                    border: 'none',
                                    borderRadius: '12px',
                                    padding: '12px 24px',
                                    color: 'white',
                                    height: '48px',
                                    transition: 'all 0.3s ease',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}
                            >
                                <FaSignOutAlt size={18} className="me-2" />
                                Logout
                            </Button>
                        </div>
                    </div>
                </Container>
            </div>

            <Container fluid style={{ maxWidth: '1400px' }}>
                {/* Filter Section */}
                <div className="d-flex justify-content-between align-items-center mb-4">
                    <div className="d-flex align-items-center gap-3">
                        <Link to="/add">
                            <Button
                                variant="primary"
                                style={{
                                    background: '#4F46E5',
                                    border: 'none',
                                    borderRadius: '12px',
                                    padding: '12px 24px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    boxShadow: '0 4px 12px rgba(79,70,229,0.2)'
                                }}
                            >
                                <FaPlus size={16} />
                                Add New Book
                            </Button>
                        </Link>

                        <Button
                            variant="light"
                            className="d-flex align-items-center gap-2"
                            onClick={() => setFilterType(filterType === 'all' ? 'available' : filterType === 'available' ? 'out-of-stock' : 'all')}
                            style={{ 
                                background: 'white',
                                border: '1px solid #e0e0e0',
                                borderRadius: '12px',
                                padding: '12px 24px',
                                fontWeight: '500',
                                boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
                            }}
                        >
                            <FaFilter size={14} />
                            {filterType === 'all' ? 'All Books' : 
                             filterType === 'available' ? 'Available Now' : 
                             'Out of Stock'}
                        </Button>

                        <Button
                            variant="light"
                            className="d-flex align-items-center gap-2"
                            onClick={() => setSortBy(sortBy === 'recent' ? 'title' : sortBy === 'title' ? 'author' : sortBy === 'author' ? 'availability' : 'recent')}
                            style={{ 
                                background: 'white',
                                border: '1px solid #e0e0e0',
                                borderRadius: '12px',
                                padding: '12px 24px',
                                fontWeight: '500',
                                boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
                            }}
                        >
                            <FaSort size={14} />
                            Sort: {sortBy.charAt(0).toUpperCase() + sortBy.slice(1)}
                        </Button>
                    </div>
                </div>

                {/* Books Grid */}
                {loading ? (
                    <div className="text-center p-5">
                        <div className="spinner-border text-primary" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </div>
                    </div>
                ) : filteredBooks.length === 0 ? (
                    <div className="text-center p-5" style={{ 
                        background: 'white', 
                        borderRadius: '20px', 
                        boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
                    }}>
                        <FaBook size={48} style={{ color: '#dee2e6' }} />
                        <h4 className="mt-4 mb-2">No books found</h4>
                        <p className="text-muted mb-4">Try adjusting your search criteria</p>
                    </div>
                ) : (
                    <Row>
                        {filteredBooks.map((book) => (
                            <Col key={book.id} lg={2} md={3} sm={4} xs={6} className="mb-4">
                                <div style={{ 
                                    cursor: 'pointer',
                                    height: '100%',
                                    position: 'relative'
                                }}>
                                    <div style={{ 
                                        position: 'relative',
                                        paddingBottom: '150%',
                                        borderRadius: '16px',
                                        overflow: 'hidden',
                                        boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                                        transition: 'all 0.3s ease'
                                    }}
                                    onMouseEnter={(e) => {
                                        e.currentTarget.style.transform = 'translateY(-8px)';
                                        e.currentTarget.style.boxShadow = '0 20px 40px rgba(0,0,0,0.2)';
                                    }}
                                    onMouseLeave={(e) => {
                                        e.currentTarget.style.transform = 'translateY(0)';
                                        e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.1)';
                                    }}>
                                        <img
                                            src={book.image_url || 'https://via.placeholder.com/300x450?text=No+Image'}
                                            alt={book.title}
                                            style={{ 
                                                position: 'absolute',
                                                top: 0,
                                                left: 0,
                                                width: '100%',
                                                height: '100%',
                                                objectFit: 'cover'
                                            }}
                                            // onError={(e) => {
                                            //     e.target.src = 'https://via.placeholder.com/300x450?text=No+Image';
                                            // }}
                                        />
                                        <div style={{
                                            position: 'absolute',
                                            top: '12px',
                                            right: '12px',
                                            background: book.copies_available > 0 ? 'rgba(72, 187, 120, 0.9)' : 'rgba(229, 62, 62, 0.9)',
                                            color: 'white',
                                            padding: '6px 12px',
                                            borderRadius: '8px',
                                            fontSize: '0.75rem',
                                            fontWeight: '600',
                                            backdropFilter: 'blur(8px)'
                                        }}>
                                            {book.copies_available > 0 ? `${book.copies_available} Available` : 'Out of Stock'}
                                        </div>
                                        <div style={{
                                            position: 'absolute',
                                            bottom: 0,
                                            left: 0,
                                            right: 0,
                                            background: 'linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0) 100%)',
                                            padding: '60px 15px 15px',
                                            color: 'white'
                                        }}>
                                            <h3 style={{ 
                                                fontSize: '0.95rem',
                                                fontWeight: '600',
                                                marginBottom: '4px',
                                                lineHeight: '1.3',
                                                overflow: 'hidden',
                                                display: '-webkit-box',
                                                WebkitLineClamp: 2,
                                                WebkitBoxOrient: 'vertical'
                                            }}>
                                                {book.title}
                                            </h3>
                                            <p style={{ 
                                                fontSize: '0.85rem',
                                                marginBottom: '12px',
                                                opacity: '0.8',
                                                overflow: 'hidden',
                                                whiteSpace: 'nowrap',
                                                textOverflow: 'ellipsis'
                                            }}>
                                                {book.author}
                                            </p>
                                            <div className="d-flex gap-2">
                                                <Link 
                                                    to={`/editbook/${book.id}`}
                                                    className="flex-grow-1"
                                                >
                                                    <Button 
                                                        variant="primary"
                                                        size="sm"
                                                        style={{
                                                            width: '100%',
                                                            fontSize: '0.85rem',
                                                            padding: '8px',
                                                            background: '#4F46E5',
                                                            border: 'none',
                                                            borderRadius: '8px',
                                                            backdropFilter: 'blur(8px)',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center'
                                                        }}
                                                    >
                                                        <FaEdit className="me-2" />
                                                        Edit
                                                    </Button>
                                                </Link>
                                                <Button 
                                                    variant="danger"
                                                    size="sm"
                                                    onClick={() => deleteBook(book.id)}
                                                    disabled={deletingBooks[book.id]}
                                                    style={{
                                                        width: '100%',
                                                        fontSize: '0.85rem',
                                                        padding: '8px',
                                                        background: '#FF4B4B',
                                                        border: 'none',
                                                        borderRadius: '8px',
                                                        backdropFilter: 'blur(8px)',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center'
                                                    }}
                                                >
                                                    {deletingBooks[book.id] ? (
                                                        <>
                                                            <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                                            Deleting...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <FaTrash className="me-2" />
                                                            Delete
                                                        </>
                                                    )}
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Col>
                        ))}
                    </Row>
                )}
            </Container>
        </div>
    );
};

export default AdminDashboard;
