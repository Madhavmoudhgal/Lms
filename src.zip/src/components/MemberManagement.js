import React, { useState, useEffect } from 'react';
import { Container, Table, Button, Row, Col, Form, Spinner } from 'react-bootstrap';
import { FaEdit, FaTrash, FaSearch, FaUserCog, FaArrowLeft, FaFilter, FaSort } from 'react-icons/fa';
import { Link, useNavigate } from 'react-router-dom';
import axiosInstance from '../axiosInstance';
import { toast } from 'react-toastify';

const MemberManagement = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredUsers, setFilteredUsers] = useState([]);
    const [deletingUsers, setDeletingUsers] = useState({});
    const [filterRole, setFilterRole] = useState('all');
    const [sortBy, setSortBy] = useState('username');
    const navigate = useNavigate();

    const fetchUsers = async () => {
        try {
            const response = await axiosInstance.get('/api/users');
            setUsers(response.data);
            setFilteredUsers(response.data);
        } catch (error) {
            console.error('Error fetching users:', error);
            toast.error('Failed to load users');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    useEffect(() => {
        let results = [...users];

        // Apply search filter
        if (searchTerm) {
            results = results.filter(user =>
                user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                user.phone?.includes(searchTerm)
            );
        }

        // Apply role filter
        if (filterRole !== 'all') {
            results = results.filter(user => user.role === filterRole);
        }

        // Apply sorting
        switch (sortBy) {
            case 'username':
                results.sort((a, b) => a.username.localeCompare(b.username));
                break;
            case 'email':
                results.sort((a, b) => a.email.localeCompare(b.email));
                break;
            case 'role':
                results.sort((a, b) => a.role.localeCompare(b.role));
                break;
            default:
                break;
        }

        setFilteredUsers(results);
    }, [searchTerm, users, filterRole, sortBy]);

    const handleDeleteUser = async (id) => {
        setDeletingUsers(prev => ({ ...prev, [id]: true }));
        try {
            const response = await axiosInstance.delete(`/api/users/${id}`);
            if (response.data.status === 'success') {
                toast.success('User deleted successfully');
                fetchUsers();
            } else {
                toast.error(response.data.message || 'Failed to delete user');
            }
        } catch (error) {
            console.error('Error deleting user:', error);
            toast.error('Failed to delete user');
        } finally {
            setDeletingUsers(prev => ({ ...prev, [id]: false }));
        }
    };

    return (
        <div className="min-vh-100" style={{ background: '#f8f9fa' }}>
            {/* Header Section */}
            <div style={{ 
                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                padding: '24px 0',
                marginBottom: '40px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
            }}>
                <Container fluid style={{ maxWidth: '1400px' }}>
                    <div className="d-flex justify-content-between align-items-center gap-4">
                        {/* Left side empty div for spacing */}
                        <div style={{ width: '200px' }}></div>

                        {/* Centered search bar */}
                        <div className="position-relative" style={{ flex: 1, maxWidth: '500px', margin: '0 auto' }}>
                            <div className="input-group">
                                <span className="input-group-text border-end-0" 
                                    style={{ 
                                        borderTopLeftRadius: '12px', 
                                        borderBottomLeftRadius: '12px',
                                        background: 'white',
                                        border: '1px solid rgba(255,255,255,0.2)'
                                    }}>
                                    <FaSearch size={16} style={{ color: '#4F46E5' }} />
                                </span>
                                <Form.Control
                                    type="text"
                                    placeholder="Search members by name, email, or phone..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    style={{
                                        height: '48px',
                                        background: 'white',
                                        border: '1px solid rgba(255,255,255,0.2)',
                                        borderLeft: 'none',
                                        color: '#1a1a1a',
                                        borderTopRightRadius: '12px',
                                        borderBottomRightRadius: '12px',
                                        fontSize: '0.95rem',
                                        boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                                    }}
                                    className="border-start-0"
                                />
                            </div>
                        </div>

                        {/* Right side buttons */}
                        <div className="d-flex align-items-center gap-3" style={{ width: '200px', justifyContent: 'flex-end' }}>
                            <Button
                                variant="transparent"
                                onClick={() => navigate('/admin-dashboard')}
                                style={{
                                    background: 'rgba(255,255,255,0.1)',
                                    backdropFilter: 'blur(10px)',
                                    border: 'none',
                                    borderRadius: '12px',
                                    padding: '12px 24px',
                                    color: 'white',
                                    height: '48px',
                                    transition: 'all 0.3s ease'
                                }}
                            >
                                <FaArrowLeft size={18} className="me-2" />
                                Back
                            </Button>
                        </div>
                    </div>
                </Container>
            </div>

            <Container fluid style={{ maxWidth: '1400px' }}>
                {/* Filter Section */}
                <div className="d-flex justify-content-between align-items-center mb-4">
                    <div className="d-flex align-items-center gap-3">
                        <Button
                            variant="light"
                            className="d-flex align-items-center gap-2"
                            onClick={() => setFilterRole(filterRole === 'all' ? 'USER' : filterRole === 'USER' ? 'ADMIN' : 'all')}
                            style={{ 
                                background: 'white',
                                border: '1px solid #e0e0e0',
                                borderRadius: '12px',
                                padding: '12px 24px',
                                fontWeight: '500',
                                boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
                            }}
                        >
                            <FaFilter size={14} />
                            {filterRole === 'all' ? 'All Members' : 
                             filterRole === 'USER' ? 'Users Only' : 
                             'Admins Only'}
                        </Button>

                        <Button
                            variant="light"
                            className="d-flex align-items-center gap-2"
                            onClick={() => setSortBy(sortBy === 'username' ? 'email' : sortBy === 'email' ? 'role' : 'username')}
                            style={{ 
                                background: 'white',
                                border: '1px solid #e0e0e0',
                                borderRadius: '12px',
                                padding: '12px 24px',
                                fontWeight: '500',
                                boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
                            }}
                        >
                            <FaSort size={14} />
                            Sort: {sortBy.charAt(0).toUpperCase() + sortBy.slice(1)}
                        </Button>
                    </div>
                </div>

                {/* Members List */}
                {loading ? (
                    <div className="text-center p-5">
                        <div className="spinner-border text-primary" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </div>
                    </div>
                ) : filteredUsers.length === 0 ? (
                    <div className="text-center p-5" style={{ 
                        background: 'white', 
                        borderRadius: '20px', 
                        boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
                    }}>
                        <FaUserCog size={48} style={{ color: '#dee2e6' }} />
                        <h4 className="mt-4 mb-2">No members found</h4>
                        <p className="text-muted mb-4">Try adjusting your search criteria</p>
                    </div>
                ) : (
                    <div className="bg-white rounded-4 shadow-sm overflow-hidden">
                        <Table hover responsive className="mb-0">
                            <thead>
                                <tr style={{ background: '#f8f9fa' }}>
                                    <th className="px-4 py-3">Username</th>
                                    <th className="px-4 py-3">Email</th>
                                    <th className="px-4 py-3">Phone</th>
                                    <th className="px-4 py-3">Role</th>
                                    <th className="px-4 py-3">Address</th>
                                    <th className="px-4 py-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredUsers.map((user) => (
                                    <tr key={user.id}>
                                        <td className="px-4 py-3">{user.username}</td>
                                        <td className="px-4 py-3">{user.email}</td>
                                        <td className="px-4 py-3">{user.phone}</td>
                                        <td className="px-4 py-3">
                                            <span className={`badge ${user.role === 'ADMIN' ? 'bg-primary' : 'bg-success'}`}
                                                style={{
                                                    padding: '8px 12px',
                                                    borderRadius: '8px',
                                                    fontSize: '0.85rem'
                                                }}
                                            >
                                                {user.role}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3">{user.address}</td>
                                        <td className="px-4 py-3">
                                            <div className="d-flex gap-2">
                                                <Button
                                                    variant="primary"
                                                    size="sm"
                                                    onClick={() => navigate(`/edit-user/${user.id}`)}
                                                    style={{
                                                        background: '#4F46E5',
                                                        border: 'none',
                                                        borderRadius: '8px',
                                                        padding: '8px 16px',
                                                        fontSize: '0.85rem',
                                                        minWidth: '100px',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center'
                                                    }}
                                                >
                                                    <FaEdit className="me-2" />
                                                    Edit
                                                </Button>
                                                <Button
                                                    variant="danger"
                                                    size="sm"
                                                    onClick={() => handleDeleteUser(user.id)}
                                                    disabled={deletingUsers[user.id]}
                                                    style={{
                                                        background: '#FF4B4B',
                                                        border: 'none',
                                                        borderRadius: '8px',
                                                        padding: '8px 16px',
                                                        fontSize: '0.85rem',
                                                        minWidth: '100px',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center'
                                                    }}
                                                >
                                                    {deletingUsers[user.id] ? (
                                                        <>
                                                            <Spinner
                                                                as="span"
                                                                animation="border"
                                                                size="sm"
                                                                role="status"
                                                                aria-hidden="true"
                                                                className="me-2"
                                                            />
                                                            Deleting...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <FaTrash className="me-2" />
                                                            Delete
                                                        </>
                                                    )}
                                                </Button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    </div>
                )}
            </Container>
        </div>
    );
};

export default MemberManagement; 