import React from 'react';
import { Form } from 'react-bootstrap';
import { FaSearch } from 'react-icons/fa';

const SearchInput = ({ value, onChange }) => (
  <div className="search-container" style={{ position: 'relative', width: '100%', maxWidth: '500px' }}>
    <div className="input-group">
      <span className="input-group-text border-end-0" 
        style={{ 
          borderTopLeftRadius: '16px', 
          borderBottomLeftRadius: '16px',
          background: 'rgba(255,255,255,0.9)',
          border: '1px solid rgba(255,255,255,0.2)',
          backdropFilter: 'blur(8px)'
        }}>
        <FaSearch size={16} style={{ color: '#4F46E5' }} />
      </span>
      <Form.Control
        type="text"
        placeholder="Search books by title..."
        value={value}
        onChange={onChange}
        style={{
          height: '48px',
          background: 'rgba(255,255,255,0.9)',
          border: '1px solid rgba(255,255,255,0.2)',
          borderLeft: 'none',
          color: '#1a1a1a',
          borderTopRightRadius: '16px',
          borderBottomRightRadius: '16px',
          fontSize: '0.95rem',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          backdropFilter: 'blur(8px)',
          transition: 'all 0.3s ease'
        }}
        className="border-start-0"
      />
    </div>
  </div>
);

export default SearchInput; 