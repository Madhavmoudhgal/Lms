import React, { useState, useEffect } from 'react';
import { Container, Card, Row, Col, Badge, Spinner, Table, Form, Button } from 'react-bootstrap';
import { FaBook, FaUser, FaExclamationTriangle, FaClock, FaSearch, FaArrowLeft, FaCheckCircle, FaMoneyBillWave, FaChartBar } from 'react-icons/fa';
import axios from '../utils/axios';
import { toast } from 'react-toastify';

const AdminReports = () => {
    const [lendings, setLendings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [filter, setFilter] = useState('all');
    const [selectedUser, setSelectedUser] = useState(null);
    const [users, setUsers] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        fetchLendings();
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        try {
            const response = await axios.get('/api/users');
            setUsers(response.data);
        } catch (err) {
            console.error('Error fetching users:', err);
        }
    };

    const fetchLendings = async () => {
        try {
            const response = await axios.get('/api/lendings/admin');
            if (response.data.status === 'success') {
                setLendings(response.data.lendings);
            } else {
                setError(response.data.message || 'Failed to fetch lendings');
            }
        } catch (err) {
            setError(err.response?.data?.message || 'Failed to fetch lendings');
        } finally {
            setLoading(false);
        }
    };

    const calculateDaysRemaining = (dueDate) => {
        const today = new Date();
        const due = new Date(dueDate);
        const diffTime = due - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
    };

    const getStatusColor = (lending) => {
        if (lending.returnDate) return 'success';
        if (new Date(lending.dueDate) < new Date()) return 'danger';
        return 'warning';
    };

    const getStatusText = (lending) => {
        if (lending.returnDate) return 'Returned';
        if (new Date(lending.dueDate) < new Date()) return 'Overdue';
        return 'Active';
    };

    const calculateFine = (lending) => {
        if (lending.returnDate || new Date(lending.dueDate) > new Date()) return 0;
        const daysOverdue = Math.abs(calculateDaysRemaining(lending.dueDate));
        return daysOverdue * 10;
    };

    const filteredLendings = lendings.filter(lending => {
        const matchesFilter = (() => {
            switch (filter) {
                case 'active': return !lending.returnDate;
                case 'overdue': return !lending.returnDate && new Date(lending.dueDate) < new Date();
                case 'returned': return lending.returnDate;
                default: return true;
            }
        })();

        const matchesUser = !selectedUser || lending.user.id === selectedUser.id;
        return matchesFilter && matchesUser;
    });

    const filteredUsers = users.filter(user => 
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const userStats = selectedUser ? {
        total: lendings.filter(l => l.user.id === selectedUser.id).length,
        active: lendings.filter(l => l.user.id === selectedUser.id && !l.returnDate).length,
        overdue: lendings.filter(l => l.user.id === selectedUser.id && !l.returnDate && new Date(l.dueDate) < new Date()).length,
        returned: lendings.filter(l => l.user.id === selectedUser.id && l.returnDate).length,
        totalFine: lendings.filter(l => l.user.id === selectedUser.id).reduce((sum, l) => sum + calculateFine(l), 0)
    } : {
        total: lendings.length,
        active: lendings.filter(l => !l.returnDate).length,
        overdue: lendings.filter(l => !l.returnDate && new Date(l.dueDate) < new Date()).length,
        returned: lendings.filter(l => l.returnDate).length,
        totalFine: lendings.reduce((sum, l) => sum + calculateFine(l), 0)
    };

    if (loading) {
        return (
            <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
                <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
                </Spinner>
            </div>
        );
    }

    if (error) {
        return (
            <div className="text-center p-4">
                <h4 className="text-danger">Error</h4>
                <p>{error}</p>
                <button className="btn btn-primary" onClick={fetchLendings}>
                    Retry
                </button>
            </div>
        );
    }

    return (
        <Container fluid className="py-4">
            {/* Header Section */}
            <div style={{ 
                background: selectedUser 
                    ? 'linear-gradient(135deg, #1a237e 0%, #0d47a1 100%)'
                    : 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                padding: '32px 0',
                marginBottom: '40px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
            }}>
                <Container fluid style={{ maxWidth: '1400px' }}>
                    <div className="d-flex justify-content-between align-items-center">
                        {selectedUser ? (
                            <div className="d-flex align-items-center">
                                <Button
                                    variant="link"
                                    className="text-white me-4 p-0"
                                    onClick={() => setSelectedUser(null)}
                                    style={{ 
                                        width: '48px', 
                                        height: '48px', 
                                        borderRadius: '50%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        background: 'rgba(255,255,255,0.1)',
                                        backdropFilter: 'blur(10px)',
                                        transition: 'all 0.3s ease'
                                    }}
                                    onMouseEnter={(e) => {
                                        e.currentTarget.style.background = 'rgba(255,255,255,0.2)';
                                        e.currentTarget.style.transform = 'translateX(-5px)';
                                    }}
                                    onMouseLeave={(e) => {
                                        e.currentTarget.style.background = 'rgba(255,255,255,0.1)';
                                        e.currentTarget.style.transform = 'translateX(0)';
                                    }}
                                >
                                    <FaArrowLeft size={20} />
                                </Button>
                                <div className="d-flex align-items-center">
                                    <div style={{
                                        width: '64px',
                                        height: '64px',
                                        borderRadius: '50%',
                                        background: 'rgba(255,255,255,0.1)',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        marginRight: '20px',
                                        border: '2px solid rgba(255,255,255,0.2)'
                                    }}>
                                        <FaUser size={32} className="text-white" />
                                    </div>
                                    <div>
                                        <h2 className="text-white mb-1">{selectedUser.username}</h2>
                                        <div className="d-flex align-items-center">
                                            <span className="text-white opacity-75 me-3">{selectedUser.email}</span>
                                            <Badge bg="light" className="text-dark">
                                                {lendings.filter(l => l.user.id === selectedUser.id).length} Books
                                            </Badge>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="d-flex align-items-center">
                                <div style={{
                                    width: '64px',
                                    height: '64px',
                                    borderRadius: '50%',
                                    background: 'rgba(255,255,255,0.1)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    marginRight: '20px',
                                    border: '2px solid rgba(255,255,255,0.2)'
                                }}>
                                    <FaChartBar size={32} className="text-white" />
                                </div>
                                <div>
                                    <h2 className="text-white mb-1">Admin Reports</h2>
                                    <div className="d-flex align-items-center">
                                        <span className="text-white opacity-75 me-3">View and manage lending history</span>
                                        <Badge bg="light" className="text-dark">
                                            {lendings.length} Total Records
                                        </Badge>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </Container>
            </div>

            <Container fluid style={{ maxWidth: '1400px' }}>
                {!selectedUser ? (
                    <>
                        {/* Users List */}
                        <Card className="mb-4 border-0 shadow-sm">
                            <Card.Header className="bg-white border-0 py-3">
                                <div className="d-flex justify-content-between align-items-center">
                                    <h5 className="mb-0 d-flex align-items-center">
                                        <FaUser className="me-2 text-primary" />
                                        Users
                                    </h5>
                                    <div style={{ width: '300px' }}>
                                        <div className="input-group">
                                            <span className="input-group-text border-end-0 bg-light">
                                                <FaSearch size={14} className="text-muted" />
                                            </span>
                                            <Form.Control
                                                type="text"
                                                placeholder="Search users..."
                                                value={searchTerm}
                                                onChange={(e) => setSearchTerm(e.target.value)}
                                                className="border-start-0 bg-light"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </Card.Header>
                            <Card.Body>
                                <div className="row g-4">
                                    {filteredUsers.map(user => (
                                        <div key={user.id} className="col-md-4">
                                            <Card 
                                                className="h-100 cursor-pointer border-0 shadow-sm"
                                                onClick={() => setSelectedUser(user)}
                                                style={{ 
                                                    cursor: 'pointer',
                                                    transition: 'all 0.3s ease',
                                                    background: 'white'
                                                }}
                                                onMouseEnter={(e) => {
                                                    e.currentTarget.style.transform = 'translateY(-5px)';
                                                    e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)';
                                                }}
                                                onMouseLeave={(e) => {
                                                    e.currentTarget.style.transform = 'translateY(0)';
                                                    e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.1)';
                                                }}
                                            >
                                                <Card.Body>
                                                    <div className="d-flex align-items-center mb-3">
                                                        <div style={{
                                                            width: '48px',
                                                            height: '48px',
                                                            borderRadius: '50%',
                                                            background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            marginRight: '16px'
                                                        }}>
                                                            <FaUser size={24} className="text-white" />
                                                        </div>
                                                        <div>
                                                            <h6 className="mb-1">{user.username}</h6>
                                                            <small className="text-muted">{user.email}</small>
                                                        </div>
                                                    </div>
                                                    <div className="d-flex justify-content-between">
                                                        <div>
                                                            <small className="text-muted d-block">Total Borrowed</small>
                                                            <h6 className="mb-0 text-primary">{lendings.filter(l => l.user.id === user.id).length}</h6>
                                                        </div>
                                                        <div>
                                                            <small className="text-muted d-block">Active</small>
                                                            <h6 className="mb-0 text-warning">{lendings.filter(l => l.user.id === user.id && !l.returnDate).length}</h6>
                                                        </div>
                                                    </div>
                                                </Card.Body>
                                            </Card>
                                        </div>
                                    ))}
                                </div>
                            </Card.Body>
                        </Card>
                    </>
                ) : (
                    <>
                        {/* User's Lending History */}
                        <Row className="mb-4 g-4">
                            <Col md={2}>
                                <Card className="h-100 border-0 shadow-sm">
                                    <Card.Body className="text-center p-4">
                                        <div className="mb-3">
                                            <div style={{
                                                width: '48px',
                                                height: '48px',
                                                borderRadius: '50%',
                                                background: 'rgba(79,70,229,0.1)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                margin: '0 auto'
                                            }}>
                                                <FaBook size={24} className="text-primary" />
                                            </div>
                                        </div>
                                        <Card.Title className="text-muted mb-2">Total Lendings</Card.Title>
                                        <h2 className="text-primary mb-0">{userStats.total}</h2>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={2}>
                                <Card className="h-100 border-0 shadow-sm">
                                    <Card.Body className="text-center p-4">
                                        <div className="mb-3">
                                            <div style={{
                                                width: '48px',
                                                height: '48px',
                                                borderRadius: '50%',
                                                background: 'rgba(255,193,7,0.1)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                margin: '0 auto'
                                            }}>
                                                <FaClock size={24} className="text-warning" />
                                            </div>
                                        </div>
                                        <Card.Title className="text-muted mb-2">Active</Card.Title>
                                        <h2 className="text-warning mb-0">{userStats.active}</h2>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={2}>
                                <Card className="h-100 border-0 shadow-sm">
                                    <Card.Body className="text-center p-4">
                                        <div className="mb-3">
                                            <div style={{
                                                width: '48px',
                                                height: '48px',
                                                borderRadius: '50%',
                                                background: 'rgba(220,53,69,0.1)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                margin: '0 auto'
                                            }}>
                                                <FaExclamationTriangle size={24} className="text-danger" />
                                            </div>
                                        </div>
                                        <Card.Title className="text-muted mb-2">Overdue</Card.Title>
                                        <h2 className="text-danger mb-0">{userStats.overdue}</h2>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={2}>
                                <Card className="h-100 border-0 shadow-sm">
                                    <Card.Body className="text-center p-4">
                                        <div className="mb-3">
                                            <div style={{
                                                width: '48px',
                                                height: '48px',
                                                borderRadius: '50%',
                                                background: 'rgba(40,167,69,0.1)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                margin: '0 auto'
                                            }}>
                                                <FaCheckCircle size={24} className="text-success" />
                                            </div>
                                        </div>
                                        <Card.Title className="text-muted mb-2">Returned</Card.Title>
                                        <h2 className="text-success mb-0">{userStats.returned}</h2>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={2}>
                                <Card className="h-100 border-0 shadow-sm">
                                    <Card.Body className="text-center p-4">
                                        <div className="mb-3">
                                            <div style={{
                                                width: '48px',
                                                height: '48px',
                                                borderRadius: '50%',
                                                background: 'rgba(255,193,7,0.1)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                margin: '0 auto'
                                            }}>
                                                <FaMoneyBillWave size={24} className="text-warning" />
                                            </div>
                                        </div>
                                        <Card.Title className="text-muted mb-2">Total Fine</Card.Title>
                                        <h2 className="text-warning mb-0">${userStats.totalFine}</h2>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={2}>
                                <Card className="h-100 border-0 shadow-sm">
                                    <Card.Body className="p-4">
                                        <Card.Title className="text-muted mb-3">Filter</Card.Title>
                                        <Form.Select 
                                            value={filter} 
                                            onChange={(e) => setFilter(e.target.value)}
                                            className="border-0 bg-light"
                                        >
                                            <option value="all">All</option>
                                            <option value="active">Active</option>
                                            <option value="overdue">Overdue</option>
                                            <option value="returned">Returned</option>
                                        </Form.Select>
                                    </Card.Body>
                                </Card>
                            </Col>
                        </Row>

                        <Card className="border-0 shadow-sm">
                            <Card.Header className="bg-white border-0 py-3">
                                <div className="d-flex justify-content-between align-items-center">
                                    <h5 className="mb-0 d-flex align-items-center">
                                        <FaBook className="me-2 text-primary" />
                                        Lending History
                                    </h5>
                                    <div className="d-flex align-items-center gap-2">
                                        <span className="text-muted">Total Records:</span>
                                        <span className="badge bg-primary px-3 py-2">{filteredLendings.length}</span>
                                    </div>
                                </div>
                            </Card.Header>
                            <Card.Body className="p-0">
                                <div className="table-responsive">
                                    <Table hover className="mb-0">
                                        <thead className="bg-light">
                                            <tr>
                                                <th className="border-0 py-3">Book Title</th>
                                                <th className="border-0 py-3">Borrow Date</th>
                                                <th className="border-0 py-3">Due Date</th>
                                                <th className="border-0 py-3">Return Date</th>
                                                <th className="border-0 py-3">Status</th>
                                                <th className="border-0 py-3">Fine</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {filteredLendings.map((lending) => (
                                                <tr key={lending.id} className="align-middle">
                                                    <td className="py-3">
                                                        <div className="d-flex align-items-center">
                                                            <div className="me-3" style={{ 
                                                                width: '48px', 
                                                                height: '48px', 
                                                                borderRadius: '8px', 
                                                                overflow: 'hidden',
                                                                boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                                                            }}>
                                                                <img 
                                                                    src={lending.book.image_url || 'https://via.placeholder.com/48x48?text=No+Image'} 
                                                                    alt={lending.book.title}
                                                                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                                                />
                                                            </div>
                                                            <div>
                                                                <div className="fw-medium">{lending.book.title}</div>
                                                                <small className="text-muted">{lending.book.author}</small>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="py-3">
                                                        <div className="text-muted">
                                                            {new Date(lending.borrowDate).toLocaleDateString()}
                                                        </div>
                                                    </td>
                                                    <td className="py-3">
                                                        <div className="text-muted">
                                                            {new Date(lending.dueDate).toLocaleDateString()}
                                                        </div>
                                                    </td>
                                                    <td className="py-3">
                                                        {lending.returnDate ? (
                                                            <div className="text-success">
                                                                {new Date(lending.returnDate).toLocaleDateString()}
                                                            </div>
                                                        ) : (
                                                            <div className="text-muted">-</div>
                                                        )}
                                                    </td>
                                                    <td className="py-3">
                                                        <Badge 
                                                            bg={getStatusColor(lending)}
                                                            className="px-3 py-1"
                                                            style={{ 
                                                                borderRadius: '20px',
                                                                fontSize: '0.85rem',
                                                                fontWeight: '500'
                                                            }}
                                                        >
                                                            {getStatusText(lending)}
                                                        </Badge>
                                                    </td>
                                                    <td className="py-3">
                                                        <div className={`fw-medium ${calculateFine(lending) > 0 ? 'text-danger' : 'text-success'}`}>
                                                            ${calculateFine(lending)}
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </Table>
                                </div>
                            </Card.Body>
                        </Card>
                    </>
                )}
            </Container>
        </Container>
    );
};

export default AdminReports; 