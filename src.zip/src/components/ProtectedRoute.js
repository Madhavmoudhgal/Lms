import React from 'react';
import { Navigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const ProtectedRoute = ({ children, requiredRole }) => {
    const role = localStorage.getItem('role');
    const username = localStorage.getItem('username');
    const token = localStorage.getItem('token');

    if (!token) {
        toast.error('Please login to continue');
        return <Navigate to="/" replace />;
    }

    // Allow access if either role is ADMIN or username is admin for admin routes
    if (requiredRole === 'ADMIN' && role !== 'ADMIN' && username !== 'admin') {
        toast.error('Access denied. Admin privileges required.');
        return <Navigate to="/user-dashboard" replace />;
    }

    return children;
};

export default ProtectedRoute; 