import axios from 'axios';
import { Link } from 'react-router-dom';
import { Button, Container, Table, Form, Row, Col } from 'react-bootstrap';
import { useState, useEffect } from 'react';
import axiosInstance from '../axiosInstance';

const BookList = () => {
    const [books, setBooks] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredBooks, setFilteredBooks] = useState([]);

    useEffect(() => {
        axiosInstance.get('/api/books')
            .then(response => {
                const bookData = response.data.content;
                setBooks(bookData);
                setFilteredBooks(bookData);
            })
            .catch(error => console.error('Error fetching books:', error));
    }, []);

    useEffect(() => {
        const results = books.filter(book =>
            book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.isbn.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.copies_available.toString().toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.image_url.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setFilteredBooks(results);
    }, [searchTerm, books]);

    const deleteBook = (id) => {
        axiosInstance.delete(`/api/books/${id}`)
            .then(() => setBooks(books.filter(book => book.id !== id)))
            .catch(error => console.error('Error deleting book:', error));
    };

    return (
        <Container fluid className="py-4">
            <div className="bg-primary text-white p-3 rounded mb-4">
                <h1 className="mb-0">Library Management System</h1>
            </div>

            <div className="bg-white rounded shadow-sm p-4">
                <Row className="mb-4">
                    <Col md={8}>
                        <Form.Control
                            type="text"
                            placeholder="Search by title, author, ISBN, or status"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="shadow-sm"
                        />
                    </Col>
                    <Col md={2}>
                        <Button variant="outline-primary" onClick={() => setSearchTerm('')}>
                            Clear
                        </Button>
                    </Col>
                    <Col md={2} className="text-end">
                        <Link to="/add" className="btn btn-primary">
                            Add Book
                        </Link>
                    </Col>
                </Row>

                <Table hover responsive>
                    <thead className="thead-light">
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>ISBN</th>
                            <th>Copies Available</th>
                            <th>Image URL</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {Array.isArray(filteredBooks) && filteredBooks.map(book => (
                            <tr key={book.id}>
                                <td>{book.id}</td>
                                <td>{book.title}</td>
                                <td>{book.author}</td>
                                <td>{book.isbn}</td>
                                <td>{book.copies_available}</td>
                                <td>{book.image_url}</td>
                                <td>
                                    <Link to={`/editbook/${book.id}`} className="btn btn-warning btn-sm me-2">
                                        Edit
                                    </Link>
                                    <Button variant="danger" size="sm" onClick={() => deleteBook(book.id)}>
                                        Delete
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </div>
        </Container>
    );
};

export default BookList;
