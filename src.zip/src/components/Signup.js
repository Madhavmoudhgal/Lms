import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Form, Button, InputGroup, Card, Modal } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { FaUser, FaEnvelope, FaLock, FaUserPlus, FaPhone, FaMapMarkerAlt, FaCheckCircle } from 'react-icons/fa';
import axios from 'axios';
import { toast } from 'react-toastify';
import '../styles/custom.css';

const Signup = () => {
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        phone: '',
        address: ''
    });
    const [loading, setLoading] = useState(false);
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        // Create particle effect
        const createParticle = () => {
            const particle = document.createElement('div');
            particle.className = 'signup-particle';
            const size = Math.random() * 15 + 5;
            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;
            particle.style.left = `${Math.random() * 100}vw`;
            particle.style.setProperty('--duration', `${Math.random() * 3 + 2}s`);
            document.querySelector('.signup-page').appendChild(particle);

            particle.addEventListener('animationend', () => {
                particle.remove();
            });
        };

        const particleInterval = setInterval(createParticle, 300);
        return () => clearInterval(particleInterval);
    }, []);

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (formData.password !== formData.confirmPassword) {
            toast.error('Passwords do not match!', {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                className: 'toast-error-custom'
            });
            return;
        }

        if (!formData.phone.match(/^\d{10}$/)) {
            toast.error('Please enter a valid 10-digit phone number', {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                className: 'toast-error-custom'
            });
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post('http://localhost:8080/api/signup', {
                username: formData.username,
                email: formData.email,
                password: formData.password,
                phone: formData.phone,
                address: formData.address
            });

            if (response.data.success) {
                setShowSuccessModal(true);
                toast.success('Account created successfully!', {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    className: 'toast-success-custom'
                });
                setTimeout(() => {
                    setShowSuccessModal(false);
                    navigate('/');
                }, 3000);
            }
        } catch (error) {
            const errorMessage = error.response?.data?.message || 'Failed to create account';
            toast.error(errorMessage, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                className: 'toast-error-custom'
            });
            console.error('Signup error:', error.response?.data);
        } finally {
            setLoading(false);
        }
    };

    const handleBackToLogin = () => {
                navigate('/');
    };

    return (
        <div className="signup-page">
            <Container className="py-5">
                <Row className="justify-content-center">
                    <Col md={8} lg={6}>
                        <Card className="signup-card">
                            <Card.Body className="p-4">
                                <div className="text-center mb-4">
                                    <div className="signup-icon-container">
                                        <FaUserPlus className="signup-icon" />
                                    </div>
                                    <h2 className="signup-title">Create Account</h2>
                                    <p className="text-muted">Join our library management system</p>
                                </div>

            <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                                        <InputGroup>
                                            <InputGroup.Text className="signup-input-icon">
                                                <FaUser />
                                            </InputGroup.Text>
                    <Form.Control
                        type="text"
                                                placeholder="Username"
                        name="username"
                                                value={formData.username}
                        onChange={handleChange}
                        required
                                                className="signup-input"
                    />
                                        </InputGroup>
                </Form.Group>

                <Form.Group className="mb-3">
                                        <InputGroup>
                                            <InputGroup.Text className="signup-input-icon">
                                                <FaEnvelope />
                                            </InputGroup.Text>
                    <Form.Control
                                                type="email"
                                                placeholder="Email address"
                                                name="email"
                                                value={formData.email}
                        onChange={handleChange}
                        required
                                                className="signup-input"
                    />
                                        </InputGroup>
                </Form.Group>

                <Form.Group className="mb-3">
                                        <InputGroup>
                                            <InputGroup.Text className="signup-input-icon">
                                                <FaPhone />
                                            </InputGroup.Text>
                    <Form.Control
                                                type="tel"
                                                placeholder="Phone number (10 digits)"
                                                name="phone"
                                                value={formData.phone}
                        onChange={handleChange}
                                                required
                                                pattern="[0-9]{10}"
                                                className="signup-input"
                                            />
                                        </InputGroup>
                </Form.Group>

                <Form.Group className="mb-3">
                                        <InputGroup>
                                            <InputGroup.Text className="signup-input-icon">
                                                <FaMapMarkerAlt />
                                            </InputGroup.Text>
                    <Form.Control
                                                as="textarea"
                                                rows={2}
                                                placeholder="Address"
                        name="address"
                                                value={formData.address}
                        onChange={handleChange}
                        required
                                                className="signup-input"
                    />
                                        </InputGroup>
                </Form.Group>

                <Form.Group className="mb-3">
                                        <InputGroup>
                                            <InputGroup.Text className="signup-input-icon">
                                                <FaLock />
                                            </InputGroup.Text>
                    <Form.Control
                        type="password"
                                                placeholder="Password"
                        name="password"
                                                value={formData.password}
                                                onChange={handleChange}
                                                required
                                                className="signup-input"
                                                minLength="6"
                                            />
                                        </InputGroup>
                                    </Form.Group>

                                    <Form.Group className="mb-4">
                                        <InputGroup>
                                            <InputGroup.Text className="signup-input-icon">
                                                <FaLock />
                                            </InputGroup.Text>
                                            <Form.Control
                                                type="password"
                                                placeholder="Confirm Password"
                                                name="confirmPassword"
                                                value={formData.confirmPassword}
                        onChange={handleChange}
                        required
                                                className="signup-input"
                                                minLength="6"
                    />
                                        </InputGroup>
                </Form.Group>

                                    <div className="d-grid gap-2">
                                        <Button
                                            type="submit"
                                            className="signup-submit-btn"
                                            disabled={loading}
                                        >
                                            {loading ? 'Creating Account...' : 'Create Account'}
                                        </Button>
                                        <Button
                                            variant="outline-secondary"
                                            onClick={handleBackToLogin}
                                            className="back-to-login-btn mt-3"
                                        >
                                            Back to Login
                                        </Button>
                                    </div>
            </Form>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
        </Container>

            {/* Success Modal */}
            <Modal
                show={showSuccessModal}
                onHide={() => setShowSuccessModal(false)}
                centered
                className="success-modal"
            >
                <Modal.Body className="text-center py-4">
                    <div className="success-icon-container mb-3">
                        <FaCheckCircle className="success-icon text-success" style={{ fontSize: '4rem' }} />
                    </div>
                    <h3 className="mb-3">Account Created Successfully!</h3>
                    <p className="text-muted mb-4">Welcome to our Library Management System</p>
                    <div className="success-animation"></div>
                </Modal.Body>
            </Modal>
        </div>
    );
};

export default Signup;