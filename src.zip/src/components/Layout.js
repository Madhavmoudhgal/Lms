import React from 'react';
import { Container, Row, Col, Nav } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Layout = ({ children }) => {
    return (
        <Container fluid>
            <Row>
                <Col md={2} className="bg-light sidebar">
                    <Nav className="flex-column">
                        <Nav.Item>
                            <Nav.Link as={Link} to="/">Home</Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                            <Nav.Link as={Link} to="/dashboard">Dashboard</Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                            <Nav.Link as={Link} to="/members">Member Management</Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                            <Nav.Link as={Link} to="/transactions">Transactions</Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                            <Nav.Link as={Link} to="/reports">Reports</Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                            <Nav.Link as={Link} to="/settings">Settings</Nav.Link>
                        </Nav.Item>
                    </Nav>
                </Col>
                <Col md={10} className="content">
                    {children}
                </Col>
            </Row>
        </Container>
    );
};

export default Layout;