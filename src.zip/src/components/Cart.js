import React, { useState, useEffect } from "react";
import { Container, Row, Col, Card, Button, Form, Badge } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { FaShoppingCart, FaTrash, FaArrowLeft, FaBook, FaTimes, FaClock } from 'react-icons/fa';
import axiosInstance from "../axiosInstance";
import { toast } from 'react-toastify';

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [removingItem, setRemovingItem] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCartItems();
  }, []);

  const fetchCartItems = async () => {
    try {
      const response = await axiosInstance.get("/cart/display");
      if (response.data.status === "success") {
        setCartItems(response.data.cartItems || []);
      }
    } catch (error) {
      console.error("Error fetching cart items:", error);
      toast.error("Failed to load cart items");
    } finally {
      setLoading(false);
    }
  };

  const removeFromCart = async (bookId) => {
    if (removingItem === bookId) return;
    
    setRemovingItem(bookId);
    try {
      const response = await axiosInstance.delete(`/cart/removeItem/${bookId}`);
      if (response.data.status === "success") {
        setCartItems(cartItems.filter(item => item.book.id !== bookId));
        toast.success('Book removed from cart');
      } else {
        toast.error(response.data.message || 'Failed to remove book');
      }
    } catch (error) {
      console.error('Error removing book from cart:', error);
      toast.error(error.response?.data?.message || 'Failed to remove book from cart');
    } finally {
      setRemovingItem(null);
    }
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.book.price || 0), 0);
  };

  const handleCheckout = async () => {
    try {
      const response = await axiosInstance.post("/cart/checkout");
      if (response.data.status === "success") {
        toast.success("Checkout successful! Books have been borrowed.");
        navigate("/user-dashboard");
      } else {
        toast.error(response.data.message || "Checkout failed");
      }
    } catch (error) {
      console.error("Error during checkout:", error);
      toast.error(error.response?.data?.message || "Checkout failed. Please try again.");
    }
  };

  return (
    <div className="min-vh-100" style={{ 
      background: 'linear-gradient(135deg, #f0f4ff 0%, #f8f9fa 100%)',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Background decorative elements */}
      <div style={{
        position: 'absolute',
        top: '-100px',
        right: '-100px',
        width: '300px',
        height: '300px',
        background: 'linear-gradient(135deg, rgba(79,70,229,0.1) 0%, rgba(124,58,237,0.1) 100%)',
        borderRadius: '50%',
        filter: 'blur(40px)',
        zIndex: 0
      }} />
      <div style={{
        position: 'absolute',
        bottom: '-100px',
        left: '-100px',
        width: '300px',
        height: '300px',
        background: 'linear-gradient(135deg, rgba(255,107,107,0.1) 0%, rgba(255,75,75,0.1) 100%)',
        borderRadius: '50%',
        filter: 'blur(40px)',
        zIndex: 0
      }} />

      <Container fluid style={{ maxWidth: '1400px' }} className="py-4 position-relative">
        <div className="bg-white rounded-4 shadow-sm p-4 mb-4" style={{
          background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
          border: '1px solid rgba(79,70,229,0.1)',
          backdropFilter: 'blur(10px)',
          boxShadow: '0 8px 32px rgba(79,70,229,0.1)'
        }}>
          <div className="d-flex align-items-center">
            <div style={{
              width: '56px',
              height: '56px',
              background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
              borderRadius: '16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: '20px',
              boxShadow: '0 4px 12px rgba(79,70,229,0.2)',
              position: 'relative',
              transition: 'transform 0.3s ease',
              cursor: 'pointer'
            }} onClick={() => navigate('/user-dashboard')}>
              <FaArrowLeft size={24} className="text-white" />
            </div>
            <div>
              <h2 className="mb-1" style={{ 
                fontSize: '1.75rem',
                fontWeight: '600',
                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}>Shopping Cart</h2>
              <p className="text-muted mb-0" style={{ 
                fontSize: '1rem',
                opacity: '0.8'
              }}>{cartItems.length} items in your cart</p>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="text-center p-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : cartItems.length === 0 ? (
          <div className="text-center p-5" style={{ 
            background: 'white', 
            borderRadius: '20px', 
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
            border: '1px solid rgba(79,70,229,0.1)',
            backdropFilter: 'blur(10px)'
          }}>
            <FaShoppingCart size={48} style={{ color: '#4F46E5', opacity: 0.5 }} />
            <h4 className="mt-4 mb-2">Your cart is empty</h4>
            <p className="text-muted mb-4">Add some books to your cart to see them here</p>
            <Button 
              variant="primary" 
              onClick={() => navigate('/user-dashboard')}
              className="px-4"
              style={{
                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                border: 'none',
                boxShadow: '0 4px 12px rgba(79,70,229,0.2)'
              }}
            >
              Browse Books
            </Button>
          </div>
        ) : (
          <Row>
            <Col lg={8}>
              <div className="bg-white rounded-4 shadow-sm overflow-hidden" style={{
                background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                border: '1px solid rgba(79,70,229,0.1)',
                backdropFilter: 'blur(10px)',
                boxShadow: '0 8px 32px rgba(79,70,229,0.1)'
              }}>
                <div className="p-4">
                  <h5 className="mb-4" style={{ 
                    color: '#4F46E5',
                    fontWeight: '600',
                    fontSize: '1.25rem'
                  }}>Cart Items</h5>
                  <div className="table-responsive">
                    <table className="table table-hover mb-0">
                      <thead>
                        <tr>
                          <th style={{ 
                            color: '#4F46E5',
                            fontWeight: '600',
                            borderBottom: '2px solid rgba(79,70,229,0.1)'
                          }}>Book</th>
                          <th style={{ 
                            color: '#4F46E5',
                            fontWeight: '600',
                            borderBottom: '2px solid rgba(79,70,229,0.1)'
                          }}>Price</th>
                          <th style={{ 
                            color: '#4F46E5',
                            fontWeight: '600',
                            borderBottom: '2px solid rgba(79,70,229,0.1)'
                          }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {cartItems.map((item) => (
                          <tr key={item.book.id} style={{
                            transition: 'all 0.3s ease',
                            ':hover': {
                              backgroundColor: 'rgba(79,70,229,0.05)'
                            }
                          }}>
                            <td>
                              <div className="d-flex align-items-center">
                                <div style={{ 
                                  width: '60px', 
                                  height: '80px', 
                                  marginRight: '16px',
                                  borderRadius: '8px',
                                  overflow: 'hidden',
                                  background: '#f8f9fa',
                                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                                  transition: 'transform 0.3s ease',
                                  ':hover': {
                                    transform: 'scale(1.05)'
                                  }
                                }}>
                                  <img
                                    src={item.book.image_url || item.book.imageUrl || 'https://via.placeholder.com/60x80?text=No+Image'}
                                    alt={item.book.title}
                                    style={{ 
                                      width: '100%', 
                                      height: '100%', 
                                      objectFit: 'cover' 
                                    }}
                                    onError={(e) => {
                                      e.target.src = 'https://via.placeholder.com/60x80?text=No+Image';
                                    }}
                                  />
                                </div>
                                <div>
                                  <h6 className="mb-1" style={{ 
                                    color: '#1a1a1a',
                                    fontWeight: '500'
                                  }}>{item.book.title}</h6>
                                  <p className="text-muted mb-0" style={{ 
                                    fontSize: '0.85rem',
                                    opacity: '0.8'
                                  }}>
                                    {item.book.author}
                                  </p>
                                </div>
                              </div>
                            </td>
                            <td style={{ 
                              color: '#4F46E5',
                              fontWeight: '500',
                              fontSize: '1.1rem'
                            }}>₹{item.book.price || 0}</td>
                            <td>
                              <Button
                                variant="outline-danger"
                                size="sm"
                                onClick={() => removeFromCart(item.book.id)}
                                disabled={removingItem === item.book.id}
                                style={{
                                  borderRadius: '8px',
                                  padding: '8px 16px',
                                  transition: 'all 0.3s ease',
                                  borderColor: '#FF4B4B',
                                  color: '#FF4B4B',
                                  ':hover': {
                                    backgroundColor: '#FF4B4B',
                                    color: 'white'
                                  }
                                }}
                              >
                                {removingItem === item.book.id ? (
                                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                ) : (
                                  <FaTrash className="me-2" />
                                )}
                                Remove
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </Col>
            <Col lg={4}>
              <Card className="border-0 shadow-sm" style={{
                background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                border: '1px solid rgba(79,70,229,0.1)',
                backdropFilter: 'blur(10px)',
                boxShadow: '0 8px 32px rgba(79,70,229,0.1)'
              }}>
                <Card.Body className="p-4">
                  <h5 className="mb-4" style={{ 
                    color: '#4F46E5',
                    fontWeight: '600',
                    fontSize: '1.25rem'
                  }}>Order Summary</h5>
                  <div className="d-flex justify-content-between mb-3">
                    <span className="text-muted">Subtotal</span>
                    <span style={{ 
                      color: '#4F46E5',
                      fontWeight: '500',
                      fontSize: '1.1rem'
                    }}>₹{calculateTotal()}</span>
                  </div>
                  <div className="d-flex justify-content-between mb-3">
                    <span className="text-muted">Shipping</span>
                    <span style={{ 
                      color: '#4F46E5',
                      fontWeight: '500',
                      fontSize: '1.1rem'
                    }}>Free</span>
                  </div>
                  <hr style={{ borderColor: 'rgba(79,70,229,0.1)' }} />
                  <div className="d-flex justify-content-between mb-4">
                    <span className="fw-bold" style={{ 
                      color: '#1a1a1a',
                      fontSize: '1.1rem'
                    }}>Total</span>
                    <span className="fw-bold" style={{ 
                      color: '#4F46E5',
                      fontSize: '1.5rem'
                    }}>₹{calculateTotal()}</span>
                  </div>
                  <Button
                    variant="primary"
                    className="w-100 py-3"
                    onClick={handleCheckout}
                    style={{
                      borderRadius: '12px',
                      background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                      border: 'none',
                      fontSize: '1rem',
                      fontWeight: '500',
                      boxShadow: '0 4px 12px rgba(79,70,229,0.2)',
                      transition: 'all 0.3s ease',
                      ':hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: '0 6px 16px rgba(79,70,229,0.3)'
                      }
                    }}
                  >
                    Proceed to Checkout
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        )}
      </Container>
    </div>
  );
};

export default Cart;
