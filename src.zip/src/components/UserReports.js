import React, { useState, useEffect } from 'react';
import { Container, Card, Row, Col, Badge, Spinner, Button } from 'react-bootstrap';
import { FaBook, FaCalendarAlt, FaClock, FaExclamationTriangle, FaArrowLeft } from 'react-icons/fa';
import axios from '../utils/axios';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const UserReports = () => {
    const [lendings, setLendings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const [stats, setStats] = useState({
        totalBorrowed: 0,
        overdueBooks: 0,
        totalFine: 0
    });

    useEffect(() => {
        fetchLendings();
    }, []);

    const fetchLendings = async () => {
        try {
            const response = await axios.get('/api/lendings/user');
            if (response.data.status === 'success') {
                setLendings(response.data.lendings);
                setStats({
                    totalBorrowed: response.data.lendings.length,
                    overdueBooks: response.data.lendings.filter(lending => {
                        const dueDate = new Date(lending.dueDate);
                        return dueDate < new Date() && !lending.returnDate;
                    }).length,
                    totalFine: response.data.lendings.filter(lending => {
                        const dueDate = new Date(lending.dueDate);
                        const now = new Date();
                        const daysOverdue = Math.ceil((now - dueDate) / (1000 * 60 * 60 * 24));
                        return daysOverdue > 0 && !lending.returnDate;
                    }).reduce((sum, lending) => {
                        const dueDate = new Date(lending.dueDate);
                        const now = new Date();
                        const daysOverdue = Math.ceil((now - dueDate) / (1000 * 60 * 60 * 24));
                        return sum + (daysOverdue * 10);
                    }, 0)
                });
            } else {
                setError(response.data.message || 'Failed to fetch lendings');
            }
        } catch (err) {
            setError(err.response?.data?.message || 'Failed to fetch lendings');
        } finally {
            setLoading(false);
        }
    };

    const calculateDaysRemaining = (dueDate) => {
        const today = new Date();
        const due = new Date(dueDate);
        const diffTime = due - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
    };

    const getStatusColor = (lending) => {
        if (lending.returnDate) return 'success';
        if (new Date(lending.dueDate) < new Date()) return 'danger';
        return 'warning';
    };

    const getStatusText = (lending) => {
        if (lending.returnDate) return 'Returned';
        if (new Date(lending.dueDate) < new Date()) return 'Overdue';
        return 'Active';
    };

    const calculateFine = (lending) => {
        if (lending.returnDate || new Date(lending.dueDate) > new Date()) return 0;
        const daysOverdue = Math.abs(calculateDaysRemaining(lending.dueDate));
        return daysOverdue * 10; // $10 per day fine
    };

    return (
        <div className="min-vh-100" style={{ 
            background: 'linear-gradient(135deg, #f0f4ff 0%, #f8f9fa 100%)',
            position: 'relative',
            overflow: 'hidden'
        }}>
            {/* Background decorative elements */}
            <div style={{
                position: 'absolute',
                top: '-100px',
                right: '-100px',
                width: '300px',
                height: '300px',
                background: 'linear-gradient(135deg, rgba(79,70,229,0.1) 0%, rgba(124,58,237,0.1) 100%)',
                borderRadius: '50%',
                filter: 'blur(40px)',
                zIndex: 0
            }} />
            <div style={{
                position: 'absolute',
                bottom: '-100px',
                left: '-100px',
                width: '300px',
                height: '300px',
                background: 'linear-gradient(135deg, rgba(255,107,107,0.1) 0%, rgba(255,75,75,0.1) 100%)',
                borderRadius: '50%',
                filter: 'blur(40px)',
                zIndex: 0
            }} />

            <Container fluid style={{ maxWidth: '1400px' }} className="py-4 position-relative">
                <div className="bg-white rounded-4 shadow-sm p-4 mb-4" style={{
                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                    border: '1px solid rgba(79,70,229,0.1)',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 8px 32px rgba(79,70,229,0.1)'
                }}>
                    <div className="d-flex align-items-center">
                        <div style={{
                            width: '56px',
                            height: '56px',
                            background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                            borderRadius: '16px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginRight: '20px',
                            boxShadow: '0 4px 12px rgba(79,70,229,0.2)',
                            transition: 'transform 0.3s ease',
                            cursor: 'pointer'
                        }} onClick={() => navigate('/user-dashboard')}>
                            <FaArrowLeft size={24} className="text-white" />
                        </div>
                        <div>
                            <h2 className="mb-1" style={{ 
                                fontSize: '1.75rem',
                                fontWeight: '600',
                                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent'
                            }}>My Reading Reports</h2>
                            <p className="text-muted mb-0" style={{ 
                                fontSize: '1rem',
                                opacity: '0.8'
                            }}>Track your borrowed books and return dates</p>
                        </div>
                    </div>
                </div>

                {error ? (
                    <div className="text-center p-5" style={{ 
                        background: 'white', 
                        borderRadius: '20px', 
                        boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                        border: '1px solid rgba(255,75,75,0.1)',
                        backdropFilter: 'blur(10px)'
                    }}>
                        <FaExclamationTriangle size={48} style={{ color: '#FF4B4B' }} />
                        <h4 className="mt-4 mb-2">Error Loading Reports</h4>
                        <p className="text-muted mb-4">{error}</p>
                        <Button 
                            variant="primary" 
                            onClick={fetchLendings}
                            className="px-4"
                            style={{
                                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                                border: 'none',
                                boxShadow: '0 4px 12px rgba(79,70,229,0.2)'
                            }}
                        >
                            Try Again
                        </Button>
                    </div>
                ) : (
                    <>
                        {/* Statistics Cards */}
                        <Row className="mb-4">
                            <Col md={4}>
                                <Card className="border-0 shadow-sm" style={{
                                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                                    border: '1px solid rgba(79,70,229,0.1)',
                                    backdropFilter: 'blur(10px)',
                                    boxShadow: '0 8px 32px rgba(79,70,229,0.1)',
                                    transition: 'transform 0.3s ease',
                                    cursor: 'pointer',
                                    ':hover': {
                                        transform: 'translateY(-5px)'
                                    }
                                }}>
                                    <Card.Body className="p-4">
                                        <div className="d-flex align-items-center">
                                            <div style={{ 
                                                background: 'linear-gradient(135deg, rgba(79,70,229,0.1) 0%, rgba(124,58,237,0.1) 100%)',
                                                padding: '16px',
                                                borderRadius: '12px',
                                                marginRight: '16px',
                                                boxShadow: '0 4px 12px rgba(79,70,229,0.1)'
                                            }}>
                                                <FaBook size={24} style={{ color: '#4F46E5' }} />
                                            </div>
                                            <div>
                                                <h6 className="text-muted mb-1">Total Books Borrowed</h6>
                                                <h3 className="mb-0" style={{ 
                                                    color: '#4F46E5',
                                                    fontSize: '2rem',
                                                    fontWeight: '600'
                                                }}>{stats.totalBorrowed}</h3>
                                            </div>
                                        </div>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={4}>
                                <Card className="border-0 shadow-sm" style={{
                                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                                    border: '1px solid rgba(255,107,107,0.1)',
                                    backdropFilter: 'blur(10px)',
                                    boxShadow: '0 8px 32px rgba(255,107,107,0.1)',
                                    transition: 'transform 0.3s ease',
                                    cursor: 'pointer',
                                    ':hover': {
                                        transform: 'translateY(-5px)'
                                    }
                                }}>
                                    <Card.Body className="p-4">
                                        <div className="d-flex align-items-center">
                                            <div style={{ 
                                                background: 'linear-gradient(135deg, rgba(255,107,107,0.1) 0%, rgba(255,75,75,0.1) 100%)',
                                                padding: '16px',
                                                borderRadius: '12px',
                                                marginRight: '16px',
                                                boxShadow: '0 4px 12px rgba(255,107,107,0.1)'
                                            }}>
                                                <FaExclamationTriangle size={24} style={{ color: '#FF4B4B' }} />
                                            </div>
                                            <div>
                                                <h6 className="text-muted mb-1">Overdue Books</h6>
                                                <h3 className="mb-0" style={{ 
                                                    color: '#FF4B4B',
                                                    fontSize: '2rem',
                                                    fontWeight: '600'
                                                }}>{stats.overdueBooks}</h3>
                                            </div>
                                        </div>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={4}>
                                <Card className="border-0 shadow-sm" style={{
                                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                                    border: '1px solid rgba(255,193,7,0.1)',
                                    backdropFilter: 'blur(10px)',
                                    boxShadow: '0 8px 32px rgba(255,193,7,0.1)',
                                    transition: 'transform 0.3s ease',
                                    cursor: 'pointer',
                                    ':hover': {
                                        transform: 'translateY(-5px)'
                                    }
                                }}>
                                    <Card.Body className="p-4">
                                        <div className="d-flex align-items-center">
                                            <div style={{ 
                                                background: 'linear-gradient(135deg, rgba(255,193,7,0.1) 0%, rgba(255,180,0,0.1) 100%)',
                                                padding: '16px',
                                                borderRadius: '12px',
                                                marginRight: '16px',
                                                boxShadow: '0 4px 12px rgba(255,193,7,0.1)'
                                            }}>
                                                <FaClock size={24} style={{ color: '#FFC107' }} />
                                            </div>
                                            <div>
                                                <h6 className="text-muted mb-1">Total Fine</h6>
                                                <h3 className="mb-0" style={{ 
                                                    color: '#FFC107',
                                                    fontSize: '2rem',
                                                    fontWeight: '600'
                                                }}>₹{stats.totalFine}</h3>
                                            </div>
                                        </div>
                                    </Card.Body>
                                </Card>
                            </Col>
                        </Row>

                        {/* Borrowed Books List */}
                        {loading ? (
                            <div className="text-center p-5">
                                <div className="spinner-border text-primary" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        ) : lendings.length === 0 ? (
                            <div className="text-center p-5" style={{ 
                                background: 'white', 
                                borderRadius: '20px', 
                                boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                                border: '1px solid rgba(79,70,229,0.1)',
                                backdropFilter: 'blur(10px)'
                            }}>
                                <FaBook size={48} style={{ color: '#4F46E5', opacity: 0.5 }} />
                                <h4 className="mt-4 mb-2">No borrowed books</h4>
                                <p className="text-muted mb-4">You haven't borrowed any books yet</p>
                            </div>
                        ) : (
                            <div className="bg-white rounded-4 shadow-sm overflow-hidden" style={{
                                background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                                border: '1px solid rgba(79,70,229,0.1)',
                                backdropFilter: 'blur(10px)',
                                boxShadow: '0 8px 32px rgba(79,70,229,0.1)'
                            }}>
                                <div className="p-4">
                                    <h5 className="mb-4" style={{ 
                                        color: '#4F46E5',
                                        fontWeight: '600',
                                        fontSize: '1.25rem'
                                    }}>Borrowed Books</h5>
                                    <div className="table-responsive">
                                        <table className="table table-hover mb-0">
                                            <thead>
                                                <tr>
                                                    <th style={{ 
                                                        color: '#4F46E5',
                                                        fontWeight: '600',
                                                        borderBottom: '2px solid rgba(79,70,229,0.1)'
                                                    }}>Book Title</th>
                                                    <th style={{ 
                                                        color: '#4F46E5',
                                                        fontWeight: '600',
                                                        borderBottom: '2px solid rgba(79,70,229,0.1)'
                                                    }}>Borrowed Date</th>
                                                    <th style={{ 
                                                        color: '#4F46E5',
                                                        fontWeight: '600',
                                                        borderBottom: '2px solid rgba(79,70,229,0.1)'
                                                    }}>Due Date</th>
                                                    <th style={{ 
                                                        color: '#4F46E5',
                                                        fontWeight: '600',
                                                        borderBottom: '2px solid rgba(79,70,229,0.1)'
                                                    }}>Status</th>
                                                    <th style={{ 
                                                        color: '#4F46E5',
                                                        fontWeight: '600',
                                                        borderBottom: '2px solid rgba(79,70,229,0.1)'
                                                    }}>Fine</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {lendings.map((lending) => {
                                                    const daysRemaining = calculateDaysRemaining(lending.dueDate);
                                                    const fine = calculateFine(lending);
                                                    
                                                    return (
                                                        <tr key={lending.id} style={{
                                                            transition: 'all 0.3s ease',
                                                            ':hover': {
                                                                backgroundColor: 'rgba(79,70,229,0.05)'
                                                            }
                                                        }}>
                                                            <td style={{ 
                                                                color: '#1a1a1a',
                                                                fontWeight: '500'
                                                            }}>{lending.book.title}</td>
                                                            <td style={{ 
                                                                color: '#4F46E5',
                                                                fontWeight: '500'
                                                            }}>{new Date(lending.borrowDate).toLocaleDateString()}</td>
                                                            <td style={{ 
                                                                color: '#4F46E5',
                                                                fontWeight: '500'
                                                            }}>{new Date(lending.dueDate).toLocaleDateString()}</td>
                                                            <td>
                                                                <Badge bg={getStatusColor(lending)} style={{
                                                                    padding: '8px 12px',
                                                                    borderRadius: '8px',
                                                                    fontWeight: '500',
                                                                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                                                                }}>
                                                                    {getStatusText(lending)}
                                                                </Badge>
                                                            </td>
                                                            <td style={{ 
                                                                color: fine > 0 ? '#FF4B4B' : '#4F46E5',
                                                                fontWeight: '500'
                                                            }}>₹{fine}</td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        )}
                    </>
                )}
            </Container>
        </div>
    );
};

export default UserReports; 