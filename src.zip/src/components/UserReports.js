import React, { useState, useEffect } from 'react';
import { Container, Card, Row, Col, Badge, Spinner, Button } from 'react-bootstrap';
import { FaBook, FaCalendarAlt, FaClock, FaExclamationTriangle, FaArrowLeft } from 'react-icons/fa';
import axiosInstance from '../axiosInstance';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const UserReports = () => {
    const [lendings, setLendings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const [stats, setStats] = useState({
        totalBorrowed: 0,
        overdueBooks: 0,
        totalFine: 0
    });
    const [userStats, setUserStats] = useState({
        total: 0,
        active: 0,
        overdue: 0,
        returned: 0
    });

    useEffect(() => {
        checkAuthAndFetchData();
    }, []);

    const checkAuthAndFetchData = async () => {
        const token = localStorage.getItem('token');
        const username = localStorage.getItem('username');
        const role = localStorage.getItem('role');
        
        // Debug logs
        console.log('Current auth state:', {
            token: token ? 'Present' : 'Missing',
            username,
            role
        });
        
        if (!token || !username) {
            toast.error('Please login to continue');
            navigate('/');
            return;
        }

        // Check if user has correct role
        if (role !== 'USER') {
            toast.error('Access denied. This page is for users only.');
            navigate('/');
            return;
        }

        try {
            await fetchLendings();
            await fetchTotalFine();
        } catch (err) {
            console.error('Error fetching data:', err);
            if (err.response?.status === 403) {
                toast.error('Access denied. Please login again.');
                localStorage.clear();
                navigate('/');
            } else {
                toast.error('Failed to fetch data. Please try again.');
            }
        }
    };

    const fetchLendings = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:8080/api/lending/history', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            // Transform the data to ensure consistent status values
            const transformedLendings = response.data.map(lending => ({
                ...lending,
                status: lending.status.toUpperCase()
            }));
            
            setLendings(transformedLendings);
            setError(null);
            
            // Calculate stats immediately after getting lendings
            calculateAndUpdateStats(transformedLendings);
        } catch (err) {
            console.error('Error fetching lendings:', err);
            toast.error('Failed to fetch lending history');
        } finally {
            setLoading(false);
        }
    };

    const calculateAndUpdateStats = (lendingData) => {
        try {
            const currentStats = {
                totalBorrowed: lendingData.length,
                active: lendingData.filter(lending => 
                    lending.status === 'BORROWED' || lending.status === 'ACTIVE'
                ).length,
                overdue: lendingData.filter(lending => 
                    lending.status === 'OVERDUE'
                ).length,
                returned: lendingData.filter(lending => 
                    lending.status === 'RETURNED'
                ).length
            };

            setUserStats({
                total: currentStats.totalBorrowed,
                active: currentStats.active,
                overdue: currentStats.overdue,
                returned: currentStats.returned
            });

            setStats(prev => ({
                ...prev,
                totalBorrowed: currentStats.totalBorrowed,
                overdueBooks: currentStats.overdue
            }));
        } catch (err) {
            console.error('Error calculating stats:', err);
        }
    };

    const fetchTotalFine = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:8080/api/fines/totalfine', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            setStats(prev => ({
                ...prev,
                totalFine: response.data.totalFine || 0
            }));
        } catch (err) {
            console.error('Error fetching total fine:', err);
            toast.error('Failed to fetch fine details');
        }
    };

    const calculateDaysRemaining = (dueDate) => {
        const today = new Date();
        const due = new Date(dueDate);
        const diffTime = due - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
    };

    const getStatusColor = (lending) => {
        if (lending.status === 'Returned') return 'success';
        if (lending.status === 'Overdue') return 'danger';
        return 'warning';
    };

    const getStatusText = (lending) => {
        return lending.status;
    };

    const handlePayFine = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.post('http://localhost:8080/api/fines/payfine', {}, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.data.status === 'success') {
                toast.success('Fine paid successfully!');
                await fetchTotalFine(); // Refresh the fine amount
            } else {
                toast.error(response.data.message || 'Failed to pay fine');
            }
        } catch (err) {
            console.error('Error paying fine:', err);
            toast.error('Failed to process payment');
        }
    };

    const handleReturnBook = async (lendingId) => {
        try {
            const token = localStorage.getItem('token');
            console.log('Attempting to return book with ID:', lendingId);

            if (!lendingId) {
                toast.error('Invalid lending ID');
                return;
            }

            const response = await axios.post(`http://localhost:8080/api/lending/return/${lendingId}`, {}, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.data.status === 'success') {
                toast.success('Book returned successfully!');
                await fetchLendings(); // Refresh the data
            } else {
                toast.error(response.data?.message || 'Failed to return book');
            }
        } catch (err) {
            console.error('Error returning book:', err);
            
            if (err.response?.status === 403) {
                toast.error('Session expired. Please login again.');
                navigate('/');
            } else if (err.response?.data?.message) {
                toast.error(err.response.data.message);
            } else {
                toast.error('Failed to return book. Please try again.');
            }
        }
    };

    return (
        <div className="min-vh-100" style={{ 
            background: 'linear-gradient(135deg, #f0f4ff 0%, #f8f9fa 100%)',
            position: 'relative',
            overflow: 'hidden'
        }}>
            {/* Background decorative elements */}
            <div style={{
                position: 'absolute',
                top: '-100px',
                right: '-100px',
                width: '300px',
                height: '300px',
                background: 'linear-gradient(135deg, rgba(79,70,229,0.1) 0%, rgba(124,58,237,0.1) 100%)',
                borderRadius: '50%',
                filter: 'blur(40px)',
                zIndex: 0
            }} />
            <div style={{
                position: 'absolute',
                bottom: '-100px',
                left: '-100px',
                width: '300px',
                height: '300px',
                background: 'linear-gradient(135deg, rgba(255,107,107,0.1) 0%, rgba(255,75,75,0.1) 100%)',
                borderRadius: '50%',
                filter: 'blur(40px)',
                zIndex: 0
            }} />

            <Container fluid style={{ maxWidth: '1400px' }} className="py-4 position-relative">
                <div className="bg-white rounded-4 shadow-sm p-4 mb-4" style={{
                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                    border: '1px solid rgba(79,70,229,0.1)',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 8px 32px rgba(79,70,229,0.1)'
                }}>
                    <div className="d-flex align-items-center">
                        <div style={{
                            width: '56px',
                            height: '56px',
                            background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                            borderRadius: '16px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginRight: '20px',
                            boxShadow: '0 4px 12px rgba(79,70,229,0.2)',
                            transition: 'transform 0.3s ease',
                            cursor: 'pointer'
                        }} onClick={() => navigate('/user-dashboard')}>
                            <FaArrowLeft size={24} className="text-white" />
                        </div>
                        <div>
                            <h2 className="mb-1" style={{ 
                                fontSize: '1.75rem',
                                fontWeight: '600',
                                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent'
                            }}>My Reading Reports</h2>
                            <p className="text-muted mb-0" style={{ 
                                fontSize: '1rem',
                                opacity: '0.8'
                            }}>Track your borrowed books and return dates</p>
                        </div>
                    </div>
                </div>

                {/* Add Stats Cards */}
                {!loading && !error && lendings.length > 0 && (
                        <Row className="mb-4">
                            <Col md={4}>
                                <Card className="border-0 shadow-sm" style={{
                                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                                    border: '1px solid rgba(79,70,229,0.1)',
                                    backdropFilter: 'blur(10px)',
                                    boxShadow: '0 8px 32px rgba(79,70,229,0.1)',
                                borderRadius: '16px'
                                }}>
                                    <Card.Body className="p-4">
                                        <div className="d-flex align-items-center">
                                            <div style={{ 
                                            background: 'rgba(79,70,229,0.1)',
                                                padding: '16px',
                                                borderRadius: '12px',
                                            marginRight: '16px'
                                            }}>
                                                <FaBook size={24} style={{ color: '#4F46E5' }} />
                                            </div>
                                            <div>
                                                <h6 className="text-muted mb-1">Total Books Borrowed</h6>
                                            <h3 className="mb-0" style={{ color: '#4F46E5' }}>{userStats.total}</h3>
                                        </div>
                                        </div>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={4}>
                                <Card className="border-0 shadow-sm" style={{
                                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                                border: '1px solid rgba(220,53,69,0.1)',
                                    backdropFilter: 'blur(10px)',
                                boxShadow: '0 8px 32px rgba(220,53,69,0.1)',
                                borderRadius: '16px'
                                }}>
                                    <Card.Body className="p-4">
                                        <div className="d-flex align-items-center">
                                            <div style={{ 
                                            background: 'rgba(220,53,69,0.1)',
                                                padding: '16px',
                                                borderRadius: '12px',
                                            marginRight: '16px'
                                            }}>
                                            <FaExclamationTriangle size={24} style={{ color: '#dc3545' }} />
                                            </div>
                                            <div>
                                                <h6 className="text-muted mb-1">Overdue Books</h6>
                                            <h3 className="mb-0" style={{ color: '#dc3545' }}>{userStats.overdue}</h3>
                                        </div>
                                        </div>
                                    </Card.Body>
                                </Card>
                            </Col>
                            <Col md={4}>
                                <Card className="border-0 shadow-sm" style={{
                                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
                                    border: '1px solid rgba(255,193,7,0.1)',
                                    backdropFilter: 'blur(10px)',
                                    boxShadow: '0 8px 32px rgba(255,193,7,0.1)',
                                borderRadius: '16px'
                                }}>
                                    <Card.Body className="p-4">
                                    <div className="d-flex align-items-center justify-content-between">
                                        <div className="d-flex align-items-center">
                                            <div style={{ 
                                                background: 'rgba(255,193,7,0.1)',
                                                padding: '16px',
                                                borderRadius: '12px',
                                                marginRight: '16px'
                                            }}>
                                                <FaClock size={24} style={{ color: '#ffc107' }} />
                                            </div>
                                            <div>
                                                <h6 className="text-muted mb-1">Total Fine</h6>
                                                <h3 className="mb-0" style={{ color: '#ffc107' }}>₹{stats.totalFine}</h3>
                                            </div>
                                        </div>
                                        {stats.totalFine > 0 ? (
                                            <Button
                                                variant="warning"
                                                onClick={handlePayFine}
                                                style={{
                                                    background: '#ffc107',
                                                    border: 'none',
                                                    borderRadius: '8px',
                                                    padding: '8px 16px',
                                                    fontWeight: '500',
                                                    boxShadow: '0 4px 12px rgba(255,193,7,0.2)',
                                                    transition: 'all 0.3s ease'
                                                }}
                                                className="ms-3"
                                            >
                                                Pay Fine
                                            </Button>
                                        ) : (
                                            <Button
                                                variant="secondary"
                                                disabled
                                                style={{
                                                    background: '#e9ecef',
                                                    border: 'none',
                                                    borderRadius: '8px',
                                                    padding: '8px 16px',
                                                    fontWeight: '500',
                                                    opacity: 0.7
                                                }}
                                                className="ms-3"
                                            >
                                                No Fine Due
                                            </Button>
                                        )}
                                        </div>
                                    </Card.Body>
                                </Card>
                            </Col>
                        </Row>
                )}

                {/* Books List */}
                        {loading ? (
                            <div className="text-center p-5">
                        <div className="spinner-border" style={{ color: '#4F46E5' }} role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                ) : error ? (
                    <div className="text-center p-5 bg-white rounded-4 shadow-sm">
                        <FaExclamationTriangle size={48} style={{ color: '#dc3545' }} className="mb-3" />
                        <h4>{error}</h4>
                    </div>
                        ) : lendings.length === 0 ? (
                    <div className="text-center p-5 bg-white rounded-4 shadow-sm">
                        <FaBook size={48} style={{ color: '#4F46E5', opacity: 0.5 }} className="mb-3" />
                        <h4 style={{ color: '#4F46E5' }}>No borrowed books found</h4>
                        <p className="text-muted">You haven't borrowed any books yet.</p>
                            </div>
                        ) : (
                    <div className="bg-white rounded-4 shadow-sm p-4">
                        <h5 className="mb-4" style={{ color: '#4F46E5' }}>Borrowed Books</h5>
                                    <div className="table-responsive">
                            <table className="table table-hover">
                                            <thead>
                                                <tr>
                                        <th style={{ borderBottom: '2px solid #4F46E5', color: '#4F46E5' }}>Book Title</th>
                                        <th style={{ borderBottom: '2px solid #4F46E5', color: '#4F46E5' }}>Borrow Date</th>
                                        <th style={{ borderBottom: '2px solid #4F46E5', color: '#4F46E5' }}>Due Date</th>
                                        <th style={{ borderBottom: '2px solid #4F46E5', color: '#4F46E5' }}>Status</th>
                                        <th style={{ borderBottom: '2px solid #4F46E5', color: '#4F46E5' }}>Fine</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                    {lendings.map((lending, index) => (
                                        <tr key={index} style={{
                                                            transition: 'all 0.3s ease',
                                                            ':hover': {
                                                                backgroundColor: 'rgba(79,70,229,0.05)'
                                                            }
                                                        }}>
                                            <td className="align-middle" style={{ fontWeight: '500' }}>
                                                {lending.bookName || lending.book?.title || 'N/A'}
                                            </td>
                                            <td className="align-middle">
                                                {new Date(lending.borrowDate).toLocaleDateString()}
                                            </td>
                                            <td className="align-middle">
                                                {new Date(lending.dueDate).toLocaleDateString()}
                                            </td>
                                            <td className="py-3">
                                                <div className="d-flex align-items-center gap-2">
                                                    <Badge bg={getStatusColor(lending)}>
                                                        {lending.status}
                                                    </Badge>
                                                </div>
                                            </td>
                                            <td className="align-middle d-flex align-items-center justify-content-between" style={{ 
                                                color: lending.fine > 0 ? '#dc3545' : 'inherit',
                                                                fontWeight: '500'
                                            }}>
                                                <span>₹{lending.fine || 0}</span>
                                                {lending.fine > 0 && (
                                                    <Badge bg="danger" style={{
                                                        padding: '6px 10px',
                                                        borderRadius: '6px',
                                                        fontSize: '0.75rem'
                                                    }}>
                                                        Unpaid
                                                                </Badge>
                                                )}
                                                            </td>
                                                        </tr>
                                    ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                )}
            </Container>
        </div>
    );
};

export default UserReports; 