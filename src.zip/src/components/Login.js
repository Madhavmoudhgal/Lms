import React, { useState, useEffect } from 'react';
import axiosInstance from '../axiosInstance';
import { Form, Button, Container, Row, Col, Card } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';
import { FaUser, FaLock, FaBook, FaSignInAlt, FaUserPlus } from 'react-icons/fa';
import axios from 'axios';
import { toast } from 'react-toastify';
import '../styles/custom.css';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        // Create particles
        const particlesContainer = document.createElement('div');
        particlesContainer.className = 'particles';
        document.querySelector('.login-page').appendChild(particlesContainer);

        // Create 20 particles
        for (let i = 0; i < 20; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.animationDelay = `${Math.random() * 15}s`;
            particle.style.animationDuration = `${15 + Math.random() * 10}s`;
            particlesContainer.appendChild(particle);
        }

        return () => {
            particlesContainer.remove();
        };
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');
        
        axios.post('http://localhost:8080/api/auth/login',
            { username, password },
            { headers: { 'Content-Type': 'application/json' } }
        )
            .then(response => {
                console.log(response.data);
                const { role, token } = response.data;
                localStorage.setItem('role', role);
                localStorage.setItem('token', token);
                localStorage.setItem('username', username);
                
                toast.success('Login successful! Redirecting...');
                
                setTimeout(() => {
                    if (role === 'ADMIN' || username === "admin") {
                        navigate('/admin-dashboard');
                    } else {
                        navigate('/user-dashboard');
                    }
                }, 1500);
            })
            .catch(error => {
                console.error('Error logging in:', error);
                toast.error('Invalid username or password. Please try again.');
                setError('Invalid username or password. Please try again.');
            })
            .finally(() => setIsLoading(false));
    };

    return (
        <div className="login-page">
            {/* Floating books animation with rotation */}
            <div className="floating-books">
                <FaBook className="floating-book book1" style={{ '--rotation': '-15deg' }} />
                <FaBook className="floating-book book2" style={{ '--rotation': '25deg' }} />
                <FaBook className="floating-book book3" style={{ '--rotation': '-5deg' }} />
            </div>

            <Container>
                <Row className="justify-content-center align-items-center min-vh-100">
                    <Col md={8} lg={6}>
                        <Card className="login-card">
                            <Card.Body className="p-5">
                                <div className="text-center mb-4">
                                    <div className="login-icon-container">
                                        <FaBook className="login-icon" />
                                    </div>
                                    <h2 className="login-title">Welcome to Library</h2>
                                    <p className="text-muted">Sign in to continue to your account</p>
                                </div>

                                {error && (
                                    <div className="alert alert-danger" role="alert">
                                        {error}
                                    </div>
                                )}

                                <Form onSubmit={handleSubmit}>
                                    <Form.Group className="mb-4">
                                        <div className="input-group">
                                            <div className="input-group-text">
                                                <FaUser />
                                            </div>
                                            <Form.Control
                                                type="text"
                                                value={username}
                                                onChange={(e) => setUsername(e.target.value)}
                                                placeholder="Enter username"
                                                required
                                                className="login-input"
                                            />
                                        </div>
                                    </Form.Group>

                                    <Form.Group className="mb-4">
                                        <div className="input-group">
                                            <div className="input-group-text">
                                                <FaLock />
                                            </div>
                                            <Form.Control
                                                type="password"
                                                value={password}
                                                onChange={(e) => setPassword(e.target.value)}
                                                placeholder="Enter password"
                                                required
                                                className="login-input"
                                            />
                                        </div>
                                    </Form.Group>

                                    <Button 
                                        variant="primary" 
                                        type="submit" 
                                        className="w-100 custom-btn login-btn mb-3"
                                        disabled={isLoading}
                                    >
                                        {isLoading ? (
                                            <>
                                                <span className="loading-spinner"></span>
                                                Signing in...
                                            </>
                                        ) : (
                                            <>
                                                <FaSignInAlt className="me-2" />
                                                Sign In
                                            </>
                                        )}
                                    </Button>

                                    <Link to="/signup" className="text-decoration-none">
                                        <Button 
                                            variant="outline-primary" 
                                            className="w-100 custom-btn signup-btn"
                                            disabled={isLoading}
                                        >
                                            <FaUserPlus className="me-2" />
                                            Create New Account
                                        </Button>
                                    </Link>
                                </Form>

                                <div className="login-footer text-center mt-4">
                                    <p className="text-muted">
                                        Discover a world of knowledge at your fingertips
                                    </p>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default Login;

