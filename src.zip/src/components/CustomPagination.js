import React from 'react';
import { FaChevronLeft, FaChevronRight } from 'react-icons/fa';

const CustomPagination = ({ currentPage, totalPages, onPageChange }) => {
  const getPageNumbers = () => {
    const delta = 2;
    const range = [];
    const rangeWithDots = [];

    for (
      let i = Math.max(2, currentPage - delta);
      i <= Math.min(totalPages - 1, currentPage + delta);
      i++
    ) {
      range.push(i);
    }

    if (currentPage - delta > 2) {
      rangeWithDots.push(1, '...');
    } else {
      rangeWithDots.push(1);
    }

    rangeWithDots.push(...range);

    if (currentPage + delta < totalPages - 1) {
      rangeWithDots.push('...', totalPages);
    } else if (totalPages > 1) {
      rangeWithDots.push(totalPages);
    }

    return rangeWithDots;
  };

  return (
    <div className="d-flex align-items-center gap-2">
      <button
        className="btn btn-icon"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        style={{
          width: '40px',
          height: '40px',
          borderRadius: '12px',
          border: '1px solid #e0e0e0',
          background: 'white',
          color: '#4F46E5',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.2s ease',
          padding: 0
        }}
      >
        <FaChevronLeft size={16} />
      </button>
      
      <div className="d-flex gap-2">
        {getPageNumbers().map((pageNumber, index) => (
          pageNumber === '...' ? (
            <span
              key={`dots-${index}`}
              className="d-flex align-items-center px-2"
              style={{ color: '#6b7280' }}
            >
              ...
            </span>
          ) : (
            <button
              key={pageNumber}
              onClick={() => onPageChange(pageNumber)}
              className={`btn ${currentPage === pageNumber ? 'btn-primary' : 'btn-light'}`}
              style={{
                width: '40px',
                height: '40px',
                borderRadius: '12px',
                border: currentPage === pageNumber ? 'none' : '1px solid #e0e0e0',
                background: currentPage === pageNumber ? '#4F46E5' : 'white',
                color: currentPage === pageNumber ? 'white' : '#1a1a1a',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s ease',
                padding: 0,
                fontWeight: '500'
              }}
            >
              {pageNumber}
            </button>
          )
        ))}
      </div>

      <button
        className="btn btn-icon"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        style={{
          width: '40px',
          height: '40px',
          borderRadius: '12px',
          border: '1px solid #e0e0e0',
          background: 'white',
          color: '#4F46E5',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.2s ease',
          padding: 0
        }}
      >
        <FaChevronRight size={16} />
      </button>
    </div>
  );
};

export default CustomPagination; 