import React, { useState, useEffect, useMemo } from "react";
import { Container, Row, Col, Card, Button, Form, Dropdown } from "react-bootstrap";
import { useNavigate, Link } from "react-router-dom";
import axiosInstance from "../axiosInstance";
import { FaShoppingCart, FaTimes, FaBook, FaUser, FaCog, FaSignOutAlt, FaSort, FaFilter, FaChartBar } from 'react-icons/fa';
import { toast } from 'react-toastify';
import CustomPagination from './CustomPagination';
import SearchInput from './SearchInput';

const UserDashboard = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cartItems, setCartItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [addingToCart, setAddingToCart] = useState({});
  const [userDetails, setUserDetails] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [booksPerPage] = useState(12);
  const [filterType, setFilterType] = useState('all');
  const [sortBy, setSortBy] = useState('recent');
  const [totalPages, setTotalPages] = useState(1);
  const [totalBooks, setTotalBooks] = useState(0);
  const navigate = useNavigate();

  // Add debounced search
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const filteredAndSortedBooks = useMemo(() => {
    let result = [...books];
    
    // Apply filter
    if (filterType === 'available') {
      result = result.filter(book => book.copies_available > 0);
    } else if (filterType === 'out-of-stock') {
      result = result.filter(book => book.copies_available === 0);
    }

    // Apply search - only by title
    if (debouncedSearchTerm) {
      const searchTermLower = debouncedSearchTerm.toLowerCase().trim();
      result = result.filter(
        (book) => book.title.toLowerCase().includes(searchTermLower)
      );
    }

    // Apply sort
    switch (sortBy) {
      case 'title':
        result.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'author':
        result.sort((a, b) => a.author.localeCompare(b.author));
        break;
      case 'availability':
        result.sort((a, b) => b.copies_available - a.copies_available);
        break;
      default: // 'recent' - assuming books are already in chronological order from API
        break;
    }

    return result;
  }, [books, filterType, sortBy, debouncedSearchTerm]);

  // Calculate pagination
  const indexOfLastBook = currentPage * booksPerPage;
  const indexOfFirstBook = indexOfLastBook - booksPerPage;
  const currentBooks = filteredAndSortedBooks.slice(indexOfFirstBook, indexOfLastBook);

  const fetchBooks = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get("/api/books", {
        params: {
          page: currentPage - 1,
          size: booksPerPage,
          sort: sortBy === 'recent' ? 'id,desc' : 
                sortBy === 'title' ? 'title,asc' :
                sortBy === 'author' ? 'author,asc' :
                sortBy === 'availability' ? 'copies_available,desc' : 'id,desc',
          filter: filterType,
          title: debouncedSearchTerm
        }
      });
      
      if (response.data) {
        setBooks(response.data.content || []);
        setTotalPages(response.data.totalPages || 1);
        setTotalBooks(response.data.totalElements || 0);
      }
    } catch (error) {
      console.error('Error fetching books:', error);
      toast.error('Failed to load books. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchCartItems = async () => {
    try {
      const response = await axiosInstance.get("/cart/display");
      if (response.data.status === "success") {
        setCartItems(response.data.cartItems || []);
      }
    } catch (error) {
      console.error("Error fetching cart items:", error);
    }
  };

  const fetchUserDetails = async () => {
    try {
      const token = localStorage.getItem('token');
      const username = localStorage.getItem('username');
      
      if (!token || !username) {
        navigate('/');
        return;
      }

      const response = await axiosInstance.get("/api/users");
      const users = response.data;
      const currentUser = users.find(user => user.username === username);
      
      if (currentUser) {
        setUserDetails(currentUser);
      } else {
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        localStorage.removeItem('role');
        navigate('/');
      }
    } catch (error) {
      console.error("Error fetching user details:", error);
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        localStorage.removeItem('role');
        navigate('/');
      } else {
        toast.error("Failed to load user details");
      }
    }
  };

  // Update useEffect to use debounced search
  useEffect(() => {
    fetchBooks();
  }, [currentPage, sortBy, filterType, debouncedSearchTerm]);

  // Update useEffect to fetch books only once on component mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/');
      return;
    }
    
    fetchCartItems();
    fetchUserDetails();
  }, [navigate]);

  const addToCart = async (book) => {
    if (addingToCart[book.id]) return;
    
    setAddingToCart({ ...addingToCart, [book.id]: true });
    try {
      const response = await axiosInstance.post(`/cart/add/${book.id}`);
      if (response.data.status === "success") {
        await fetchCartItems();
        toast.success('Book added to cart successfully!');
      }
    } catch (error) {
      console.error('Error adding book to cart:', error);
      if (error.response?.status === 400) {
        toast.error(error.response.data.message || 'Book already in cart or not available');
      } else {
        toast.error('Failed to add book to cart. Please try again.');
      }
    } finally {
      setAddingToCart({ ...addingToCart, [book.id]: false });
    }
  };

  const goToCart = () => navigate("/cart");

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
    toast.success('Logged out successfully');
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo(0, 0);
  };

  // Add debounce hook
  function useDebounce(value, delay) {
    const [debouncedValue, setDebouncedValue] = useState(value);

    useEffect(() => {
      const handler = setTimeout(() => {
        setDebouncedValue(value);
      }, delay);

      return () => {
        clearTimeout(handler);
      };
    }, [value, delay]);

    return debouncedValue;
  }

  // Update search handler
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1); // Reset to first page when searching
  };

  return (
    <div className="min-vh-100" style={{ background: '#f8f9fa' }}>
      {/* Header Section */}
      <div style={{ 
        background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)',
        padding: '24px 0',
        marginBottom: '40px',
        boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
      }}>
        <Container fluid style={{ maxWidth: '1400px' }}>
          <div className="d-flex justify-content-between align-items-center gap-4">
            {/* Left side empty div for spacing */}
            <div style={{ width: '200px' }}></div>

            {/* Centered search bar */}
            <div className="position-relative" style={{ flex: 1, maxWidth: '500px', margin: '0 auto' }}>
              <SearchInput value={searchTerm} onChange={handleSearch} />
            </div>

            {/* Right side buttons */}
            <div className="d-flex align-items-center gap-3" style={{ width: '200px', justifyContent: 'flex-end' }}>
              <Link to="/user-reports" style={{ textDecoration: 'none' }}>
                <Button
                  variant="transparent"
                  className="d-flex align-items-center"
                  style={{
                    background: 'rgba(255,255,255,0.1)',
                    backdropFilter: 'blur(10px)',
                    border: 'none',
                    borderRadius: '12px',
                    padding: '12px 24px',
                    color: 'white',
                    height: '48px',
                    transition: 'all 0.3s ease',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <FaChartBar size={18} className="me-2" />
                  Reports
                </Button>
              </Link>
              <Button
                variant="transparent"
                onClick={goToCart}
                className="position-relative d-flex align-items-center"
                style={{
                  background: 'rgba(255,255,255,0.1)',
                  backdropFilter: 'blur(10px)',
                  border: 'none',
                  borderRadius: '12px',
                  padding: '12px 24px',
                  color: 'white',
                  height: '48px',
                  transition: 'all 0.3s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <FaShoppingCart size={18} className="me-2" />
                Cart
                {cartItems.length > 0 && (
                  <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    {cartItems.length}
                  </span>
                )}
              </Button>
              <Dropdown align="end">
                <Dropdown.Toggle
                  variant="transparent"
                  className="d-flex align-items-center"
                  style={{
                    background: 'rgba(255,255,255,0.1)',
                    backdropFilter: 'blur(10px)',
                    border: 'none',
                    borderRadius: '12px',
                    padding: '12px 24px',
                    color: 'white',
                    height: '48px',
                    transition: 'all 0.3s ease',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <FaUser size={18} className="me-2" />
                  {userDetails?.username || 'User'}
                </Dropdown.Toggle>
                <Dropdown.Menu style={{
                  borderRadius: '12px',
                  padding: '8px',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                  border: 'none'
                }}>
                  <Dropdown.Item 
                    className="rounded-3 px-3 py-2"
                    onClick={() => navigate('/profile-settings')}
                  >
                    <FaUser className="me-2" /> Profile
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item 
                    className="rounded-3 px-3 py-2 text-danger"
                    onClick={handleLogout}
                  >
                    <FaSignOutAlt className="me-2" /> Logout
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
          </div>
        </Container>
      </div>

      <Container fluid style={{ maxWidth: '1400px', padding: '0 24px' }}>
        {/* Filter Section with modern styling */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div className="d-flex align-items-center gap-3">
            <Dropdown align="end">
              <Dropdown.Toggle variant="light" className="d-flex align-items-center gap-2" 
                style={{ 
                  background: 'white',
                  border: '1px solid #e0e0e0',
                  borderRadius: '12px',
                  padding: '10px 20px',
                  fontWeight: '500',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                  transition: 'all 0.3s ease'
                }}>
                <FaFilter size={14} />
                {filterType === 'all' ? 'All Books' : 
                 filterType === 'available' ? 'Available Now' : 
                 'Out of Stock'}
              </Dropdown.Toggle>
              <Dropdown.Menu style={{
                borderRadius: '12px',
                padding: '8px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                border: 'none'
              }}>
                <Dropdown.Item 
                  className="rounded-3 px-3 py-2"
                  active={filterType === 'all'}
                  onClick={() => setFilterType('all')}
                >
                  All Books
                </Dropdown.Item>
                <Dropdown.Item 
                  className="rounded-3 px-3 py-2"
                  active={filterType === 'available'}
                  onClick={() => setFilterType('available')}
                >
                  Available Now
                </Dropdown.Item>
                <Dropdown.Item 
                  className="rounded-3 px-3 py-2"
                  active={filterType === 'out-of-stock'}
                  onClick={() => setFilterType('out-of-stock')}
                >
                  Out of Stock
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>

            <Dropdown align="end">
              <Dropdown.Toggle variant="light" className="d-flex align-items-center gap-2"
                style={{ 
                  background: 'white',
                  border: '1px solid #e0e0e0',
                  borderRadius: '12px',
                  padding: '10px 20px',
                  fontWeight: '500',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                  transition: 'all 0.3s ease'
                }}>
                <FaSort size={14} />
                Sort by: {sortBy.charAt(0).toUpperCase() + sortBy.slice(1)}
              </Dropdown.Toggle>
              <Dropdown.Menu style={{
                borderRadius: '12px',
                padding: '8px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                border: 'none'
              }}>
                <Dropdown.Item 
                  className="rounded-3 px-3 py-2"
                  active={sortBy === 'recent'}
                  onClick={() => setSortBy('recent')}
                >
                  Recent
                </Dropdown.Item>
                <Dropdown.Item 
                  className="rounded-3 px-3 py-2"
                  active={sortBy === 'title'}
                  onClick={() => setSortBy('title')}
                >
                  Title
                </Dropdown.Item>
                <Dropdown.Item 
                  className="rounded-3 px-3 py-2"
                  active={sortBy === 'author'}
                  onClick={() => setSortBy('author')}
                >
                  Author
                </Dropdown.Item>
                <Dropdown.Item 
                  className="rounded-3 px-3 py-2"
                  active={sortBy === 'availability'}
                  onClick={() => setSortBy('availability')}
                >
                  Availability
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>

        {/* Books Grid with improved spacing */}
        {loading ? (
          <div className="text-center p-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : books.length === 0 ? (
          <div className="text-center p-5 bg-white rounded-4 shadow-sm">
            <FaBook size={48} style={{ color: '#dee2e6' }} />
            <h4 className="mt-3 mb-2">No books found</h4>
            <p className="text-muted">Try adjusting your search criteria</p>
          </div>
        ) : (
          <>
            <Row className="g-4">
              {books.map((book) => (
                <Col key={book.id} lg={2} md={3} sm={4} xs={6}>
                  <div style={{ 
                    cursor: 'pointer',
                    height: '100%',
                    position: 'relative'
                  }}>
                    <div style={{ 
                      position: 'relative',
                      paddingBottom: '150%',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                      transition: 'all 0.3s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'translateY(-8px)';
                      e.currentTarget.style.boxShadow = '0 20px 40px rgba(0,0,0,0.2)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.1)';
                    }}>
                      <img
                        src={book.image_url || 'https://via.placeholder.com/300x450?text=No+Image'}
                        alt={book.title}
                        style={{ 
                          position: 'absolute',
                          top: 0,
                          left: 0,
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover'
                        }}
                        onError={(e) => {
                          e.target.src = 'https://via.placeholder.com/300x450?text=No+Image';
                        }}
                      />
                      <div style={{
                        position: 'absolute',
                        top: '12px',
                        right: '12px',
                        background: book.copies_available > 0 ? 'rgba(72, 187, 120, 0.9)' : 'rgba(229, 62, 62, 0.9)',
                        color: 'white',
                        padding: '6px 12px',
                        borderRadius: '8px',
                        fontSize: '0.75rem',
                        fontWeight: '600',
                        backdropFilter: 'blur(8px)'
                      }}>
                        {book.copies_available > 0 ? `${book.copies_available} Available` : 'Out of Stock'}
                      </div>
                      <div style={{
                        position: 'absolute',
                        bottom: 0,
                        left: 0,
                        right: 0,
                        background: 'linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0) 100%)',
                        padding: '60px 15px 15px',
                        color: 'white'
                      }}>
                        <h3 style={{ 
                          fontSize: '0.95rem',
                          fontWeight: '600',
                          marginBottom: '4px',
                          lineHeight: '1.3',
                          overflow: 'hidden',
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical'
                        }}>
                          {book.title}
                        </h3>
                        <p style={{ 
                          fontSize: '0.85rem',
                          marginBottom: '12px',
                          opacity: '0.8',
                          overflow: 'hidden',
                          whiteSpace: 'nowrap',
                          textOverflow: 'ellipsis'
                        }}>
                          {book.author}
                        </p>
                        <Button 
                          variant={book.copies_available > 0 ? "primary" : "secondary"}
                          onClick={() => addToCart(book)}
                          disabled={book.copies_available === 0 || addingToCart[book.id]}
                          size="sm"
                          style={{
                            width: '100%',
                            fontSize: '0.85rem',
                            padding: '8px',
                            background: book.copies_available > 0 ? '#4F46E5' : 'rgba(255,255,255,0.2)',
                            border: 'none',
                            borderRadius: '8px',
                            backdropFilter: 'blur(8px)',
                            transition: 'all 0.3s ease'
                          }}
                        >
                          {addingToCart[book.id] ? (
                            <>
                              <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                              Adding...
                            </>
                          ) : book.copies_available > 0 ? (
                            <>
                              <FaShoppingCart className="me-2" />
                              Add to Cart
                            </>
                          ) : (
                            'Out of Stock'
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </Col>
              ))}
            </Row>

            {/* Enhanced Pagination with modern styling */}
            {totalPages > 1 && (
              <div className="d-flex justify-content-between align-items-center mt-5 mb-4 flex-wrap gap-3">
                <div className="text-muted" style={{ fontSize: '0.95rem' }}>
                  Showing <span className="fw-medium">{((currentPage - 1) * booksPerPage) + 1}</span> to{' '}
                  <span className="fw-medium">{Math.min(currentPage * booksPerPage, totalBooks)}</span> of{' '}
                  <span className="fw-medium">{totalBooks}</span> books
                </div>
                <CustomPagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={handlePageChange}
                />
              </div>
            )}
          </>
        )}
      </Container>
    </div>
  );
};

export default UserDashboard;
