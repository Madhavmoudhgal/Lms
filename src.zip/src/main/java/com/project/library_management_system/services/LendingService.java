package com.project.library_management_system.services;

import com.project.library_management_system.dto.LendingDto;
import com.project.library_management_system.entity.LendingEntity;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface LendingService {
    List<LendingEntity> getAllLendings();
    ResponseEntity<Map<String, Object>> markAsCollected(Long id);
    ResponseEntity<Map<String, Object>> markAsReturned(Long id);
    List<LendingDto> displayLendingsDetails();
    Integer getBorrowedBooks();
    Long getTotalOverdueBooks();
    List<LendingDto> getHistory();
} 