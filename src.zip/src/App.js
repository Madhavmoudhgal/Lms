import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import BookList from './components/BookList';
import EditBook from './components/EditBook';
import AddBook from './components/AddBook';
import Login from './components/Login';
import Signup from './components/Signup';
import AdminDashboard from './components/AdminDashboard';
import UserDashboard from './components/UserDashboard';
import Cart from './components/Cart'; // Import the Cart component
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import MemberManagement from './components/MemberManagement';
import EditUser from './components/EditUser';
import ProfileSettings from './components/ProfileSettings';
import UserReports from './components/UserReports';
import AdminReports from './components/AdminReports';

// Protected Route with role check
const ProtectedRoute = ({ element: Component, allowedRoles, ...rest }) => {
  const token = localStorage.getItem('token');
  const userRole = localStorage.getItem('role');
  
  if (!token) {
    return <Navigate to="/" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(userRole)) {
    // If user's role is not in the allowed roles, redirect to their appropriate dashboard
    return <Navigate to={userRole === 'ADMIN' ? '/admin-dashboard' : '/user-dashboard'} replace />;
  }

  return <Component {...rest} />;
};

function App() {
  return (
    <Router>
      <ToastContainer
        position="bottom-center"
        autoClose={2000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="colored"
      />
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* Admin-only routes */}
        <Route 
          path="/admin-dashboard" 
          element={<ProtectedRoute element={AdminDashboard} allowedRoles={['ADMIN']} />} 
        />
        <Route 
          path="/admin-reports" 
          element={<ProtectedRoute element={AdminReports} allowedRoles={['ADMIN']} />} 
        />
        <Route 
          path="/add" 
          element={<ProtectedRoute element={AddBook} allowedRoles={['ADMIN']} />} 
        />
        <Route 
          path="/booklist" 
          element={<ProtectedRoute element={BookList} allowedRoles={['ADMIN']} />} 
        />
        <Route 
          path="/editbook/:id" 
          element={<ProtectedRoute element={EditBook} allowedRoles={['ADMIN']} />} 
        />
        <Route 
          path="/member-management" 
          element={<ProtectedRoute element={MemberManagement} allowedRoles={['ADMIN']} />} 
        />
        <Route 
          path="/edit-user/:id" 
          element={<ProtectedRoute element={EditUser} allowedRoles={['ADMIN']} />} 
        />

        {/* User-only routes */}
        <Route 
          path="/user-dashboard" 
          element={<ProtectedRoute element={UserDashboard} allowedRoles={['USER']} />} 
        />
        <Route 
          path="/user-reports" 
          element={<ProtectedRoute element={UserReports} allowedRoles={['USER']} />} 
        />
        <Route 
          path="/cart" 
          element={<ProtectedRoute element={Cart} allowedRoles={['USER']} />} 
        />

        {/* Profile routes */}
        <Route 
          path="/profile-settings" 
          element={<ProtectedRoute element={ProfileSettings} allowedRoles={['USER']} />} 
        />

        {/* Catch all route - redirect to appropriate dashboard based on role */}
        <Route 
          path="*" 
          element={
            <Navigate 
              to={localStorage.getItem('role') === 'ADMIN' ? '/admin-dashboard' : '/user-dashboard'} 
              replace 
            />
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;
