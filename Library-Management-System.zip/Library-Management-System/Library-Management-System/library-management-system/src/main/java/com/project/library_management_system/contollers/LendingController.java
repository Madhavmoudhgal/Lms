package com.project.library_management_system.contollers;

import com.project.library_management_system.entity.LendingEntity;
import com.project.library_management_system.entity.userEntity;
import com.project.library_management_system.repository.LendingRepository;
import com.project.library_management_system.repository.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin("http://localhost:3000/")
@RestController
@RequestMapping("/api/lendings")
public class LendingController {

    @Autowired
    private LendingRepository lendingRepository;

    @Autowired
    private userRepository userRepository;

    @GetMapping("/user")
    public ResponseEntity<Map<String, Object>> getUserLendings() {
        Map<String, Object> response = new HashMap<>();
        try {
            UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String username = userDetails.getUsername();
            
            userEntity user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

            List<LendingEntity> lendings = lendingRepository.findByUser(user);
            response.put("status", "success");
            response.put("lendings", lendings);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @GetMapping("/admin")
    public ResponseEntity<Map<String, Object>> getAllLendings() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<LendingEntity> lendings = lendingRepository.findAll();
            response.put("status", "success");
            response.put("lendings", lendings);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
} 