package com.project.library_management_system.contollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.library_management_system.dto.LoginDTO;
import com.project.library_management_system.services.AuthService;

import java.util.Map;
import java.util.Objects;

@CrossOrigin("http://localhost:3000/")
@RestController
@RequestMapping("/api/auth")
public class AuthControllers {
    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginDTO loginDTO) {
        //TODO: process POST request
        return authService.loginUser(loginDTO);
    }
    
}
